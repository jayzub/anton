using Microsoft.Data.Sqlite;

namespace Serene.Tests.Services;

public class ListKeysetPaginationSqliteTests
{
    public enum ItemState
    {
        Draft = 1,
        Published = 2,
        Archived = 3
    }

    [TableName("SqliteKeysetItems")]
    private class SqliteKeysetRow : Row<SqliteKeysetRow.RowFields>, IIdRow, INameRow, IIsActiveDeletedRow
    {
        [IdProperty]
        public int? Id { get => fields.Id[this]; set => fields.Id[this] = value; }

        [NameProperty, QuickSearch]
        public string? Name { get => fields.Name[this]; set => fields.Name[this] = value; }

        public int? Rank { get => fields.Rank[this]; set => fields.Rank[this] = value; }

        public DateTime? EventTime { get => fields.EventTime[this]; set => fields.EventTime[this] = value; }

        public DateTimeOffset? EventOffset { get => fields.EventOffset[this]; set => fields.EventOffset[this] = value; }

        public Guid? ExternalId { get => fields.ExternalId[this]; set => fields.ExternalId[this] = value; }

        public decimal? Price { get => fields.Price[this]; set => fields.Price[this] = value; }

        public double? Score { get => fields.Score[this]; set => fields.Score[this] = value; }

        public bool? Featured { get => fields.Featured[this]; set => fields.Featured[this] = value; }

        public ItemState? State { get => fields.State[this]; set => fields.State[this] = value; }

        public short? IsActive { get => fields.IsActive[this]; set => fields.IsActive[this] = value; }

        Int16Field IIsActiveRow.IsActiveField => fields.IsActive;

        public class RowFields : RowFieldsBase
        {
            public Int32Field Id = null!;
            public StringField Name = null!;
            public Int32Field Rank = null!;
            public DateTimeField EventTime = null!;
            public DateTimeOffsetField EventOffset = null!;
            public GuidField ExternalId = null!;
            public DecimalField Price = null!;
            public DoubleField Score = null!;
            public BooleanField Featured = null!;
            public EnumField<ItemState> State = null!;
            public Int16Field IsActive = null!;
        }
    }

    [TableName("SqliteGuidItems")]
    private class SqliteGuidKeyRow : Row<SqliteGuidKeyRow.RowFields>, IIdRow
    {
        [IdProperty]
        public Guid? Id { get => fields.Id[this]; set => fields.Id[this] = value; }

        public string? GroupKey { get => fields.GroupKey[this]; set => fields.GroupKey[this] = value; }

        public class RowFields : RowFieldsBase
        {
            public GuidField Id = null!;
            public StringField GroupKey = null!;
        }
    }

    private sealed class SqliteLocalizationBehavior : BaseListBehavior, IListMapFieldExpressionBehavior
    {
        public override void OnPrepareQuery(IListRequestHandler handler, SqlQuery query)
        {
            query.LeftJoin("SqliteKeysetItemsLang", new Alias("jLoc"),
                new Criteria("jLoc.ItemId = T0.Id AND jLoc.CultureId = 'de'"));
        }

        public string? MapFieldExpression(IListRequestHandler handler, SqlQuery query, IField field)
        {
            if (field.Name == nameof(SqliteKeysetRow.Name))
                return "COALESCE(jLoc.Name, T0.Name)";
            return null;
        }
    }

    private static IRequestContext CreateContext(IBehaviorProvider? behaviors = null) =>
        new NullRequestContext(behaviors).WithPermissions(_ => true);

    private static IDbConnection OpenInMemorySqlite()
    {
        var raw = new SqliteConnection("Data Source=:memory:");
        raw.Open();
        using var cmd = raw.CreateCommand();
        cmd.CommandText = """
            CREATE TABLE SqliteKeysetItems (
                Id INTEGER PRIMARY KEY,
                Name TEXT NULL,
                Rank INTEGER NULL,
                EventTime TEXT NULL,
                EventOffset TEXT NULL,
                ExternalId TEXT NULL,
                Price TEXT NULL,
                Score REAL NULL,
                Featured INTEGER NULL,
                State INTEGER NULL,
                IsActive INTEGER NOT NULL DEFAULT 1
            );
            CREATE TABLE SqliteKeysetItemsLang (
                LangId INTEGER PRIMARY KEY AUTOINCREMENT,
                ItemId INTEGER NOT NULL,
                CultureId TEXT NOT NULL,
                Name TEXT NULL
            );
            CREATE TABLE SqliteGuidItems (
                Id TEXT PRIMARY KEY,
                GroupKey TEXT NULL
            );
            """;
        cmd.ExecuteNonQuery();
        return new WrappedConnection(raw, SqliteDialect.Instance);
    }

    [Fact]
    public async Task Live_Sqlite_EndToEnd_MultiColumn_Nulls_Types_Localization_And_TotalCount()
    {
        using var conn = OpenInMemorySqlite();
        var ctx = CreateContext();

        var baseTime = new DateTime(2026, 3, 15, 10, 20, 30, DateTimeKind.Utc).AddTicks(1234567);
        var baseOffset = new DateTimeOffset(new DateTime(2026, 3, 15, 10, 20, 30).AddTicks(2345678), TimeSpan.FromHours(2));

        // Insert 9 active rows + 1 inactive row with NULLs, ties, sub-ms ticks, Guids, decimals, floats, bools, enums
        int?[] ranks = [null, null, 10, 10, 10, 20, 20, 30, 30, 99];
        string?[] names = [null, "Alpha", null, "Alpha", "Beta", null, "Gamma", "Delta", "Epsilon", "Deleted"];

        for (var i = 0; i < 10; i++)
        {
            SqlHelper.ExecuteNonQuery(conn, """
                INSERT INTO SqliteKeysetItems
                    (Id, Name, Rank, EventTime, EventOffset, ExternalId, Price, Score, Featured, State, IsActive)
                VALUES
                    (@id, @name, @rank, @et, @eo, @gid, @price, @score, @feat, @state, @active)
                """,
                new Dictionary<string, object?>
                {
                    ["@id"] = i + 1,
                    ["@name"] = names[i],
                    ["@rank"] = ranks[i],
                    ["@et"] = baseTime.AddTicks(i * 3), // sub-millisecond 300ns steps!
                    ["@eo"] = baseOffset.AddTicks(i * 5),
                    ["@gid"] = Guid.Parse($"00000000-0000-0000-0000-0000000000{(i + 1):D2}"),
                    ["@price"] = 100.12345678m + i * 0.00000001m,
                    ["@score"] = Math.PI + i * 1e-12,
                    ["@feat"] = i % 2 == 0,
                    ["@state"] = (int)(ItemState)((i % 3) + 1),
                    ["@active"] = i == 9 ? (short)-1 : (short)1
                });
        }

        // Verify ALL single-type & multi-column ASC/DESC sorts against full unpaginated SQLite query!
        SortBy[][] sortsToVerify =
        [
            [new(nameof(SqliteKeysetRow.Rank), false), new(nameof(SqliteKeysetRow.Name), false)],
            [new(nameof(SqliteKeysetRow.Rank), true), new(nameof(SqliteKeysetRow.Name), false)],
            [new(nameof(SqliteKeysetRow.Rank), false), new(nameof(SqliteKeysetRow.Name), true)],
            [new(nameof(SqliteKeysetRow.Rank), true), new(nameof(SqliteKeysetRow.Name), true)],
            [new(nameof(SqliteKeysetRow.EventTime), false)],
            [new(nameof(SqliteKeysetRow.EventTime), true)],
            [new(nameof(SqliteKeysetRow.EventOffset), false)],
            [new(nameof(SqliteKeysetRow.ExternalId), false)],
            [new(nameof(SqliteKeysetRow.Price), false)],
            [new(nameof(SqliteKeysetRow.Score), false)],
            [new(nameof(SqliteKeysetRow.Featured), false), new(nameof(SqliteKeysetRow.State), true)]
        ];

        foreach (var sort in sortsToVerify)
        {
            var fullUnpaged = new ListRequestHandler<SqliteKeysetRow>(ctx).List(conn, new ListRequest
            {
                Sort = sort
            });
            var expectedIds = fullUnpaged.Entities.Select(x => x.Id!.Value).ToList();
            Assert.Equal(9, expectedIds.Count);

            // Walk sync with Take = 2 AND check TotalCount == 9 on EVERY single page!
            var pagedSyncIds = new List<int>();
            string? tok = null;
            do
            {
                var page = new ListRequestHandler<SqliteKeysetRow>(ctx).List(conn, new ListRequest
                {
                    Take = 2,
                    Sort = sort,
                    ColumnSelection = ColumnSelection.KeyOnly,
                    PageToken = tok
                });
                Assert.Equal(9, page.TotalCount);
                Assert.Equal(2, page.Take);
                Assert.Equal(0, page.Skip);
                pagedSyncIds.AddRange(page.Entities.Select(x => x.Id!.Value));
                tok = page.NextPageToken;
            }
            while (tok is not null);

            Assert.Equal(expectedIds, pagedSyncIds);

            // Walk async with Take = 1 (strictest single-row boundary test!)
            var pagedAsyncIds = new List<int>();
            tok = null;
            do
            {
                var page = await new ListRequestHandlerAsync<SqliteKeysetRow>(ctx).ListAsync(conn, new ListRequest
                {
                    Take = 1,
                    Sort = sort,
                    ExcludeColumns = [nameof(SqliteKeysetRow.Name), nameof(SqliteKeysetRow.Rank)],
                    PageToken = tok
                }, TestContext.Current.CancellationToken);
                Assert.Equal(9, page.TotalCount);
                Assert.Equal(1, page.Take);
                Assert.Equal(0, page.Skip);
                pagedAsyncIds.AddRange(page.Entities.Select(x => x.Id!.Value));
                tok = page.NextPageToken;
            }
            while (tok is not null);

            Assert.Equal(expectedIds, pagedAsyncIds);
        }

        // Verify Guid primary key tiebreaker in live SQLite
        var guids = new[]
        {
            Guid.Parse("30000000-0000-0000-0000-000000000003"),
            Guid.Parse("10000000-0000-0000-0000-000000000001"),
            Guid.Parse("20000000-0000-0000-0000-000000000002")
        };
        foreach (var g in guids)
        {
            SqlHelper.ExecuteNonQuery(conn,
                "INSERT INTO SqliteGuidItems (Id, GroupKey) VALUES (@id, @grp)",
                new Dictionary<string, object?> { ["@id"] = g, ["@grp"] = "Same" });
        }

        var gPage1 = new ListRequestHandler<SqliteGuidKeyRow>(ctx).List(conn, new ListRequest
        {
            Take = 2,
            Sort = [new SortBy(nameof(SqliteGuidKeyRow.GroupKey))]
        });
        var gPage2 = new ListRequestHandler<SqliteGuidKeyRow>(ctx).List(conn, new ListRequest
        {
            Take = 2,
            Sort = [new SortBy(nameof(SqliteGuidKeyRow.GroupKey))],
            PageToken = gPage1.NextPageToken
        });
        Assert.Equal([guids[1], guids[2]], gPage1.Entities.Select(x => x.Id!.Value));
        Assert.Equal([guids[0]], gPage2.Entities.Select(x => x.Id!.Value));
        Assert.Null(gPage2.NextPageToken);

        // Verify LEFT JOIN + COALESCE localization rewrite in live SQLite
        SqlHelper.ExecuteNonQuery(conn, """
            INSERT INTO SqliteKeysetItemsLang (ItemId, CultureId, Name) VALUES
            (8, 'de', '000_Erste'),
            (4, 'de', 'ZZZ_Letzte');
            """);
        var locCtx = CreateContext(new MockBehaviorProvider((_, _, _) => new object[] { new SqliteLocalizationBehavior() }));
        var unpagedLoc = new ListRequestHandler<SqliteKeysetRow>(locCtx)
            .List(conn, new ListRequest { Sort = [new SortBy(nameof(SqliteKeysetRow.Name))] })
            .Entities.Select(x => x.Id!.Value).ToList();

        var pagedLoc = new List<int>();
        string? locTok = null;
        do
        {
            var r = await new ListRequestHandlerAsync<SqliteKeysetRow>(locCtx).ListAsync(conn, new ListRequest
            {
                Take = 2,
                Sort = [new SortBy(nameof(SqliteKeysetRow.Name))],
                PageToken = locTok
            }, TestContext.Current.CancellationToken);
            pagedLoc.AddRange(r.Entities.Select(x => x.Id!.Value));
            locTok = r.NextPageToken;
        }
        while (locTok is not null);

        Assert.Equal(unpagedLoc, pagedLoc);
    }
}
