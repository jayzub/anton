
    /// <inheritdoc/>
    public int Take { get; set; }

    /// <summary>
    /// Continuation token for fetching the next page when keyset pagination is active
    /// and additional rows exist; otherwise <c>null</c>.
    /// </summary>
    public string? NextPageToken { get; set; }
}
