using System.Threading;

namespace Serenity.Services;

public class ListRequestHandlerKeysetTests
{
    private static string Sql(string text) => text?.Replace("[", "").Replace("]", "").Replace("\"", "").Replace("`", "");

    private static IRequestContext Context() => new NullRequestContext().WithPermissions(_ => true);
    private static ListRequest Request(string? token = null) => new() { Take = 1, ExcludeTotalCount = true, PageToken = token };

    private static async Task<(ListResponse<TRow> Response, SqlQuery Query)> Run<TRow>(bool async,
        MockDbConnection connection, ListRequest request) where TRow : class, IRow, new()
    {
        if (async)
        {
            var handler = new ListRequestHandlerAsync<TRow>(Context());
            return (await handler.ListAsync(connection, request, TestContext.Current.CancellationToken), handler.Query);
        }
        else
        {
            var handler = new ListRequestHandler<TRow>(Context());
            return (handler.List(connection, request), handler.Query);
        }
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task Pages_Overfetch_Trim_And_Use_Last_Returned_Row(bool async)
    {
        using var connection = new MockDbConnection().InterceptExecuteReader(args =>
            args.ToMockReader(new { ID = 10, Name = "same" }, new { ID = 20, Name = "same" }));
        var first = await Run<IdNameRow>(async, connection, Request());
        Assert.Equal(2, first.Query.Take());
        Assert.Equal(1, first.Response.Take);
        Assert.Equal(0, first.Response.Skip);
        Assert.Equal(10, Assert.Single(first.Response.Entities).ID);
        Assert.Matches("^[A-Za-z0-9_-]+$", first.Response.NextPageToken!);
        Assert.Equal(new[] { "T0.Name", "T0.ID" }, ((ISqlQuery)first.Query).OrderBy.Select(Sql));

        connection.InterceptExecuteReader(args => args.ToMockReader(new { ID = 20, Name = "same" }));
        var second = await Run<IdNameRow>(!async, connection, Request(first.Response.NextPageToken));
        Assert.Null(second.Response.NextPageToken);
        Assert.Equal(20, Assert.Single(second.Response.Entities).ID);
        Assert.Equal(1, second.Response.Take);
        Assert.Equal(0, second.Response.Skip);
        Assert.Contains("T0.Name > @", Sql(((ISqlQuery)second.Query).Where));
        Assert.Contains("T0.Name = @", Sql(((ISqlQuery)second.Query).Where));
        Assert.Contains("T0.ID > @", Sql(((ISqlQuery)second.Query).Where));
        Assert.Contains(10, second.Query.Params.Values);
        Assert.DoesNotContain(20, second.Query.Params.Values);
        Assert.DoesNotContain("same", Sql(((ISqlQuery)second.Query).Where));

        connection.InterceptExecuteReader(_ => new MockDbDataReader());
        var empty = await Run<IdNameRow>(async, connection, Request(first.Response.NextPageToken));
        Assert.Empty(empty.Response.Entities);
        Assert.Null(empty.Response.NextPageToken);
    }

    public static IEnumerable<object[]> InvalidRequests()
    {
        foreach (var async in new[] { false, true })
            foreach (var kind in new[] { "Take", "Skip", "Distinct", "EmptyDistinct", "Sort", "Criteria",
                "Equality", "ContainsText", "ContainsField", "IncludeDeleted", "Corrupt", "Malformed", "Empty" })
                yield return [async, kind];
    }

    [Theory]
    [MemberData(nameof(InvalidRequests))]
    public async Task Rejects_Invalid_Or_Replayed_Tokens(bool async, string kind)
    {
        using var connection = new MockDbConnection().InterceptExecuteReader(args =>
            args.ToMockReader(new { ID = 1, Name = "A" }, new { ID = 2, Name = "B" }));
        var first = await Run<IdNameRow>(async, connection, Request());
        var request = Request(first.Response.NextPageToken);
        switch (kind)
        {
            case "Take": request.Take = 0; break;
            case "Skip": request.Skip = 1; break;
            case "Distinct": request.DistinctFields = [new("Name")]; break;
            case "EmptyDistinct": request.DistinctFields = []; break;
            case "Sort": request.Sort = [new("Name", true)]; break;
            case "Criteria": request.Criteria = new Criteria("ID") > 0; break;
            case "Equality": request.EqualityFilter = new() { ["Name"] = "A" }; break;
            case "ContainsText": request.ContainsText = "A"; break;
            case "ContainsField": request.ContainsField = "NoSuchField"; break;
            case "IncludeDeleted": request.IncludeDeleted = true; break;
            case "Corrupt":
                var token = request.PageToken!;
                request.PageToken = token[..40] + (token[40] == 'A' ? "B" : "A") + token[41..];
                break;
            case "Malformed": request.PageToken = "not a token"; break;
            case "Empty": request.PageToken = ""; break;
        }
        await Assert.ThrowsAsync<ValidationError>(() => Run<IdNameRow>(async, connection, request));
        Assert.Single(connection.ExecuteReaderCalls);
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task Ineligible_First_Pages_Remain_Offset_Pages(bool async)
    {
        using var connection = new MockDbConnection().InterceptExecuteReader(_ => new MockDbDataReader());
        foreach (var request in new[] { new ListRequest(), new ListRequest { Take = -1 },
            new ListRequest { Take = 2, Skip = 1 }, new ListRequest { Take = 2, DistinctFields = [] },
            new ListRequest { Take = 2, DistinctFields = [new("Name")] } })
        {
            var page = await Run<IdNameRow>(async, connection, request);
            Assert.Null(page.Response.NextPageToken);
            Assert.Equal(request.Take, page.Query.Take());
        }
        var noId = await Run<NoIdRow>(async, connection, Request());
        Assert.Null(noId.Response.NextPageToken);
        await Assert.ThrowsAsync<ValidationError>(() => Run<NoIdRow>(async, connection, Request("anything")));
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task Selects_Excluded_Sort_And_Id_Columns(bool async)
    {
        using var connection = new MockDbConnection().InterceptExecuteReader(args =>
            args.ToMockReader(new { ID = 1, Name = "A" }, new { ID = 2, Name = "B" }));
        var request = Request();
        request.ColumnSelection = ColumnSelection.KeyOnly;
        request.ExcludeColumns = ["Name", "ID"];
        var page = await Run<IdNameRow>(async, connection, request);
        Assert.Equal("A", Assert.Single(page.Response.Entities).Name);
        Assert.NotNull(page.Response.NextPageToken);
        Assert.Equal(2, ((ISqlQueryExtensible)page.Query).Columns.Count);
    }

    public static IEnumerable<object[]> NullOrderCases()
    {
        foreach (var dialect in new ISqlDialect[] { SqlServer2012Dialect.Instance, MySqlDialect.Instance,
            SqliteDialect.Instance, PostgresDialect.Instance, OracleDialect.Instance, FirebirdDialect.Instance })
            foreach (var descending in new[] { false, true })
                foreach (var isNull in new[] { false, true })
                    foreach (var async in new[] { false, true })
                        yield return [dialect.ServerType, descending, isNull, async];
    }

    [Theory]
    [MemberData(nameof(NullOrderCases))]
    public async Task Seek_Respects_Dialect_Null_Order(string server, bool descending, bool isNull, bool async)
    {
        var dialect = new ISqlDialect[] { SqlServer2012Dialect.Instance, MySqlDialect.Instance,
            SqliteDialect.Instance, PostgresDialect.Instance, OracleDialect.Instance, FirebirdDialect.Instance }
            .Single(x => x.ServerType == server);
        using var connection = new MockDbConnection { Dialect = dialect };
        connection.InterceptExecuteReader(args => args.ToMockReader(
            new { ID = 1, Name = isNull ? null : "A" }, new { ID = 2, Name = "B" }));
        var request = Request();
        request.Sort = [new("Name", descending)];
        var first = await Run<IdNameRow>(async, connection, request);
        request.PageToken = first.Response.NextPageToken;
        var second = await Run<IdNameRow>(async, connection, request);
        var where = Sql(((ISqlQuery)second.Query).Where!);
        var nullsFirst = descending == (server is "Postgres" or "Oracle" or "Firebird");
        if (isNull)
        {
            Assert.Equal(nullsFirst, where.Contains("T0.Name IS NOT NULL"));
            Assert.Contains("T0.Name IS NULL", where);
            Assert.DoesNotContain("T0.Name = @", where);
        }
        else
        {
            Assert.Equal(!nullsFirst, where.Contains("T0.Name IS NULL"));
            Assert.Contains("T0.Name " + (descending ? "<" : ">") + " @", where);
            Assert.Contains("T0.Name = @", where);
            Assert.Contains("A", second.Query.Params.Values);
        }
        Assert.Contains("T0.ID > @", where);
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task Total_Count_Does_Not_Include_Seek_Filter(bool async)
    {
        using var connection = new MockDbConnection { Dialect = SqliteDialect.Instance };
        connection.InterceptExecuteScalar(_ => 42).InterceptExecuteReader(args => args.ToMockReader(
            new { ID = 1, Name = "A" }, new { ID = 2, Name = "A" }));
        var request = Request();
        request.ExcludeTotalCount = false;
        request.EqualityFilter = new() { ["Name"] = "A" };
        var first = await Run<IdNameRow>(async, connection, request);
        request.PageToken = first.Response.NextPageToken;
        var second = await Run<IdNameRow>(async, connection, request);
        Assert.Equal(42, first.Response.TotalCount);
        Assert.Equal(42, second.Response.TotalCount);
        var countSql = Sql(connection.ExecuteScalarCalls.Last().CommandText);
        Assert.Contains("T0.Name = @", countSql);
        Assert.DoesNotContain("T0.ID >", countSql);
        Assert.DoesNotContain("T0.Name >", countSql);
        Assert.Equal(second.Query.ToString(), second.Query.Clone().ToString());
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task Explicit_Id_Sort_Is_Not_Appended_Again(bool async)
    {
        using var connection = new MockDbConnection().InterceptExecuteReader(args => args.ToMockReader(
            new { ID = 3, Name = "A" }, new { ID = 2, Name = "B" }));
        var request = Request();
        request.Sort = [new("ID", true)];
        var first = await Run<IdNameRow>(async, connection, request);
        request.PageToken = first.Response.NextPageToken;
        var second = await Run<IdNameRow>(async, connection, request);
        Assert.Equal("T0.ID DESC", Sql(Assert.Single(((ISqlQuery)second.Query).OrderBy)));
        Assert.Contains("T0.ID < @", Sql(((ISqlQuery)second.Query).Where));
    }

    private class NativeHandler() : SeededHandler<IdNameRow>([new() { ID = 1, Name = "A" }, new() { ID = 2, Name = "B" }])
    {
        protected override SortBy[] GetNativeSort() => [new("Name", true), new("ID", true)];
    }

    [Fact]
    public void Native_First_Page_Order_Is_Preserved_Verbatim_And_Handler_State_Is_Reset()
    {
        using var connection = new MockDbConnection();
        var handler = new NativeHandler();
        var first = handler.List(connection, Request());
        var expected = ((ISqlQuery)handler.Query).OrderBy.ToArray();
        Assert.Equal(new[] { "T0.Name DESC", "T0.ID DESC" }, expected.Select(Sql));
        var second = handler.List(connection, Request(first.NextPageToken));
        Assert.Equal(expected, ((ISqlQuery)handler.Query).OrderBy);
        var inactive = handler.List(connection, new ListRequest());
        Assert.Null(inactive.NextPageToken);
        Assert.Equal(expected, ((ISqlQuery)handler.Query).OrderBy);
        Assert.Null(((ISqlQuery)handler.Query).Where);
        Assert.Equal(0, handler.Query.Take());
    }

    private class ProcessingHandler() : ListRequestHandler<IdNameRow>(Context())
    {
        public int Processed;
        protected override IdNameRow ProcessEntity(IdNameRow row) { Processed++; return row; }
        protected override void OnAfterExecuteQuery() => Assert.Single(Response.Entities);
    }

    private class ProcessingAsyncHandler() : ListRequestHandlerAsync<IdNameRow>(Context())
    {
        public int Processed;
        protected override IdNameRow ProcessEntity(IdNameRow row) { Processed++; return row; }
        protected override Task OnAfterExecuteQueryAsync(CancellationToken cancellationToken)
        {
            Assert.Single(Response.Entities);
            return Task.CompletedTask;
        }
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task Probe_Is_Not_Processed_Or_Exposed_To_After_Query_Behaviors(bool async)
    {
        using var connection = new MockDbConnection().InterceptExecuteReader(args => args.ToMockReader(
            new { ID = 1, Name = "A" }, new { ID = 2, Name = "B" }));
        if (async)
        {
            var handler = new ProcessingAsyncHandler();
            Assert.NotNull((await handler.ListAsync(connection, Request(), TestContext.Current.CancellationToken)).NextPageToken);
            Assert.Equal(1, handler.Processed);
        }
        else
        {
            var handler = new ProcessingHandler();
            Assert.NotNull(handler.List(connection, Request()).NextPageToken);
            Assert.Equal(1, handler.Processed);
        }
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task Equivalent_Sort_And_Reordered_Equality_Filters_Can_Resume(bool async)
    {
        using var connection = new MockDbConnection().InterceptExecuteReader(args => args.ToMockReader(
            new { ID = 1, Name = "A" }, new { ID = 2, Name = "B" }));
        var request = Request();
        request.EqualityFilter = new() { ["Name"] = "A", ["ID"] = 1 };
        var first = await Run<IdNameRow>(async, connection, request);
        request.PageToken = first.Response.NextPageToken;
        request.EqualityFilter = new() { ["ID"] = 1L, ["Name"] = "A" };
        request.Sort = [new(" Name "), new(" ID ")];
        request.Take = 10;
        var second = await Run<IdNameRow>(async, connection, request);
        Assert.Equal(10, second.Response.Take);
        Assert.Null(second.Response.NextPageToken);
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task Maximum_Take_Does_Not_Overflow(bool async)
    {
        using var connection = new MockDbConnection().InterceptExecuteReader(_ => new MockDbDataReader());
        var request = Request();
        request.Take = int.MaxValue;
        var result = await Run<IdNameRow>(async, connection, request);
        Assert.Equal(int.MaxValue, result.Query.Take());
        Assert.Equal(int.MaxValue, result.Response.Take);
        Assert.Null(result.Response.NextPageToken);
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task Mixed_Directions_Use_Lexicographic_Seek(bool async)
    {
        using var connection = new MockDbConnection();
        var rows = new TypedRow[] { new() { ID = 10, Text = "group", Decimal = 12.50m }, new() { ID = 11 } };
        var request = Request();
        request.Sort = [new("Text"), new("Decimal", true)];
        SqlQuery query;
        if (async)
        {
            var handler = new SeededAsyncHandler<TypedRow>(rows);
            request.PageToken = (await handler.ListAsync(connection, request, TestContext.Current.CancellationToken)).NextPageToken;
            await handler.ListAsync(connection, request, TestContext.Current.CancellationToken);
            query = handler.Query;
        }
        else
        {
            var handler = new SeededHandler<TypedRow>(rows);
            request.PageToken = handler.List(connection, request).NextPageToken;
            handler.List(connection, request);
            query = handler.Query;
        }
        Assert.Equal(new[] { "T0.Text", "T0.Decimal DESC", "T0.ID" }, ((ISqlQuery)query).OrderBy.Select(Sql));
        Assert.Equal("(((T0.Text > @p1) OR ((T0.Text = @p2) AND ((T0.Decimal < @p3) OR T0.Decimal IS NULL))) OR " +
            "(((T0.Text = @p4) AND (T0.Decimal = @p5)) AND (T0.ID > @p6)))", Sql(((ISqlQuery)query).Where));
        Assert.Equal(new object[] { "group", "group", 12.50m, "group", 12.50m, 10 }, query.Params.Values);
    }

    private class NoIdRow : Row<NoIdRow.RowFields>
    {
        public string Name { get => fields.Name[this]; set => fields.Name[this] = value; }
        public class RowFields : RowFieldsBase { public StringField Name = null!; }
    }

    private class SeededHandler<TRow>(TRow[] rows) : ListRequestHandler<TRow>(Context()) where TRow : class, IRow, new()
    {
        protected override void ExecuteQuery() => Response.Entities.AddRange(rows);
    }

    private class SeededAsyncHandler<TRow>(TRow[] rows) : ListRequestHandlerAsync<TRow>(Context()) where TRow : class, IRow, new()
    {
        protected override Task ExecuteQueryAsync(CancellationToken cancellationToken)
        {
            Response.Entities.AddRange(rows);
            return Task.CompletedTask;
        }
    }

    private class MappedHandler() : SeededHandler<IdNameRow>([new() { ID = 1, Name = "mapped" }, new() { ID = 2, Name = "probe" }])
    {
        protected override string MapFieldExpression(IField field, SqlQuery query) =>
            field.Name == "Name" ? "COALESCE(T0.Name, 'fallback')" : null;
    }

    [Fact]
    public void Mapped_Expressions_Are_Used_For_Selection_Order_And_Seek()
    {
        using var connection = new MockDbConnection();
        var handler = new MappedHandler();
        var request = Request();
        request.ColumnSelection = ColumnSelection.IdOnly;
        var first = handler.List(connection, request);
        request.PageToken = first.NextPageToken;
        handler.List(connection, request);
        Assert.Contains("COALESCE(T0.Name, 'fallback')", ((ISqlQuery)handler.Query).OrderBy);
        Assert.Contains("COALESCE(T0.Name, 'fallback') > @", ((ISqlQuery)handler.Query).Where);
        Assert.Contains("mapped", handler.Query.Params.Values);
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task Boundary_Values_Retain_Their_Types_And_Precision(bool async)
    {
        var row = new TypedRow
        {
            ID = 123,
            Date = new DateTime(638799999999999999, DateTimeKind.Utc),
            Offset = new DateTimeOffset(638799999999999999, TimeSpan.FromMinutes(345)),
            Guid = Guid.NewGuid(),
            Decimal = 1234567890.1234567890123456789m,
            Double = Math.BitIncrement(0.1d),
            Single = MathF.BitIncrement(0.1f),
            Boolean = true,
            Enum = DayOfWeek.Wednesday,
            Text = "a\0雪😀",
            Null = null
        };
        using var connection = new MockDbConnection();
        var request = Request();
        request.Sort = TypedRow.Fields.Select(x => new SortBy(x.Name)).ToArray();
        SqlQuery query;
        if (async)
        {
            var handler = new SeededAsyncHandler<TypedRow>([row, new()]);
            request.PageToken = (await handler.ListAsync(connection, request, TestContext.Current.CancellationToken)).NextPageToken;
            await handler.ListAsync(connection, request, TestContext.Current.CancellationToken);
            query = handler.Query;
        }
        else
        {
            var handler = new SeededHandler<TypedRow>([row, new()]);
            request.PageToken = handler.List(connection, request).NextPageToken;
            handler.List(connection, request);
            query = handler.Query;
        }
        foreach (var field in TypedRow.Fields)
        {
            var expected = field.AsObject(row);
            if (expected == null)
                continue;
            Assert.Contains(query.Params.Values, actual => actual?.GetType() == expected.GetType() && Equals(expected, actual));
        }
        Assert.Equal(row.Date.Value.ToBinary(), query.Params.Values.OfType<DateTime>().First().ToBinary());
        Assert.Equal(row.Offset.Value.Offset, query.Params.Values.OfType<DateTimeOffset>().First().Offset);
        Assert.Equal(decimal.GetBits(row.Decimal.Value), decimal.GetBits(query.Params.Values.OfType<decimal>().First()));
    }

    private class TypedRow : Row<TypedRow.RowFields>, IIdRow
    {
        [IdProperty]
        public int? ID { get => fields.ID[this]; set => fields.ID[this] = value; }
        public DateTime? Date { get => fields.Date[this]; set => fields.Date[this] = value; }
        public DateTimeOffset? Offset { get => fields.Offset[this]; set => fields.Offset[this] = value; }
        public Guid? Guid { get => fields.Guid[this]; set => fields.Guid[this] = value; }
        public decimal? Decimal { get => fields.Decimal[this]; set => fields.Decimal[this] = value; }
        public double? Double { get => fields.Double[this]; set => fields.Double[this] = value; }
        public float? Single { get => fields.Single[this]; set => fields.Single[this] = value; }
        public bool? Boolean { get => fields.Boolean[this]; set => fields.Boolean[this] = value; }
        public DayOfWeek? Enum { get => fields.Enum[this]; set => fields.Enum[this] = value; }
        public string Text { get => fields.Text[this]; set => fields.Text[this] = value; }
        public string Null { get => fields.Null[this]; set => fields.Null[this] = value; }
        public class RowFields : RowFieldsBase
        {
            public Int32Field ID = null!;
            public DateTimeField Date = null!;
            public DateTimeOffsetField Offset = null!;
            public GuidField Guid = null!;
            public DecimalField Decimal = null!;
            public DoubleField Double = null!;
            public SingleField Single = null!;
            public BooleanField Boolean = null!;
            public EnumField<DayOfWeek> Enum = null!;
            public StringField Text = null!;
            public StringField Null = null!;
        }
    }
}
