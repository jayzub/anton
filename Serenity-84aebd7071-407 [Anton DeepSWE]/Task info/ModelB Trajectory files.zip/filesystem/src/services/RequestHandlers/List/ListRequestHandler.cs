                        Response.Values!.Add(field.AsObject(clone)!);
                }
                else
                    TryAddEntityWithKeysetProbe(clone);
            });
        }
        catch (Exception exception)
        StateBag.Clear();
        lookupAccessMode = false;
        ignoredEqualityFilters = null;
        ResetKeysetState();
        Connection = connection ?? throw new ArgumentNullException(nameof(connection));
        Request = request ?? throw new ArgumentNullException(nameof(request));
        ValidateRequest();
        if (DistinctFields != null)
            Response.Values = [];

        InitializeKeysetPagination();

        PrepareQuery(query);
        FinalizeKeysetPreparation(query);

        var isContinuation = keysetBoundaryValues is not null;
        if (DistinctFields == null && !isContinuation)
            ApplyKeyOrder(query);

        query.ApplySkipTakeAndCount(request.Skip, GetEffectiveQueryTake(),
            request.ExcludeTotalCount || DistinctFields != null);

        ApplyContainsText(query, request.ContainsText);

        if (DistinctFields == null)
        {
            if (isContinuation)
                ApplyKeysetContinuationOrder(query);
            else
                ApplySort(query);
        }

        ApplyFilters(query);
        ApplyKeysetSeekFilter(query);

        OnBeforeExecuteQuery();

        }

        Response.SetSkipTakeTotal(query);
        CompleteKeysetPagination();

        OnAfterExecuteQuery();

