using System.IO;
using System.Security.Cryptography;

namespace Serenity.Services;

/// <summary>
/// Private, versioned wire format for list continuations. Tokens are authenticated
/// and encrypted, and intentionally valid only for this application lifetime.
/// No runtime type names from untrusted input are resolved or instantiated.
/// </summary>
internal static class ListPageToken
{
    private static readonly byte[] key = RandomNumberGenerator.GetBytes(32);

    internal static ValidationError Invalid() => new("InvalidPageToken", "PageToken",
        "The page token is invalid or does not match this list request.");

    internal static string Write(byte[] fingerprint, object?[] values)
    {
        using var stream = new MemoryStream();
        using (var writer = new BinaryWriter(stream, Encoding.UTF8, leaveOpen: true))
        {
            writer.Write((byte)1);
            writer.Write(fingerprint);
            writer.Write(values.Length);
            foreach (var value in values)
                WriteValue(writer, value);
        }

        var plaintext = stream.ToArray();
        var output = new byte[12 + 16 + plaintext.Length];
        RandomNumberGenerator.Fill(output.AsSpan(0, 12));
        using var aes = new AesGcm(key, 16);
        aes.Encrypt(output.AsSpan(0, 12), plaintext, output.AsSpan(28), output.AsSpan(12, 16));
        return Encode(output);
    }

    internal static object?[] Read(string token, byte[] fingerprint, Field[] fields)
    {
        try
        {
            if (token.Length < 40 || token.Any(c => !char.IsAsciiLetterOrDigit(c) && c != '-' && c != '_'))
                throw Invalid();
            var encoded = token.Replace('-', '+').Replace('_', '/');
            var bytes = Convert.FromBase64String(encoded.PadRight((encoded.Length + 3) / 4 * 4, '='));
            // Reject alternate encodings with nonzero unused padding bits as well.
            if (Encode(bytes) != token)
                throw Invalid();
            var plaintext = new byte[bytes.Length - 28];
            using var aes = new AesGcm(key, 16);
            aes.Decrypt(bytes.AsSpan(0, 12), bytes.AsSpan(28), bytes.AsSpan(12, 16), plaintext);
            using var stream = new MemoryStream(plaintext);
            using var reader = new BinaryReader(stream, Encoding.UTF8);
            if (reader.ReadByte() != 1 || !reader.ReadBytes(32).AsSpan().SequenceEqual(fingerprint) ||
                reader.ReadInt32() != fields.Length)
                throw Invalid();

            var values = fields.Select(field => ReadValue(reader, field)).ToArray();
            if (stream.Position != stream.Length)
                throw Invalid();
            return values;
        }
        catch (Exception ex) when (ex is CryptographicException or ArgumentException or
            IOException or FormatException or OverflowException)
        {
            throw Invalid();
        }
    }

    private static string Encode(byte[] bytes) => Convert.ToBase64String(bytes)
        .TrimEnd('=').Replace('+', '-').Replace('/', '_');

    // Binary primitives retain decimal scale, all floating-point bits, DateTime
    // kind/ticks and DateTimeOffset offset/ticks, independently of JSON settings.
    private static void WriteValue(BinaryWriter writer, object? value)
    {
        switch (value)
        {
            case null or DBNull: writer.Write((byte)0); break;
            case string x: writer.Write((byte)1); writer.Write(x); break;
            case bool x: writer.Write((byte)2); writer.Write(x); break;
            case byte x: writer.Write((byte)3); writer.Write(x); break;
            case sbyte x: writer.Write((byte)4); writer.Write(x); break;
            case short x: writer.Write((byte)5); writer.Write(x); break;
            case ushort x: writer.Write((byte)6); writer.Write(x); break;
            case int x: writer.Write((byte)7); writer.Write(x); break;
            case uint x: writer.Write((byte)8); writer.Write(x); break;
            case long x: writer.Write((byte)9); writer.Write(x); break;
            case ulong x: writer.Write((byte)10); writer.Write(x); break;
            case decimal x: writer.Write((byte)11); writer.Write(x); break;
            case float x: writer.Write((byte)12); writer.Write(x); break;
            case double x: writer.Write((byte)13); writer.Write(x); break;
            case DateTime x: writer.Write((byte)14); writer.Write(x.ToBinary()); break;
            case DateTimeOffset x:
                writer.Write((byte)15); writer.Write(x.Ticks); writer.Write(x.Offset.Ticks); break;
            case Guid x: writer.Write((byte)16); writer.Write(x.ToByteArray()); break;
            case Enum x:
                writer.Write((byte)17);
                writer.Write(x.GetType().FullName!);
                WriteValue(writer, Convert.ChangeType(x, Enum.GetUnderlyingType(x.GetType()), CultureInfo.InvariantCulture));
                break;
            default: throw new InvalidOperationException($"Unsupported page token value type: {value.GetType()}");
        }
    }

    private static object? ReadValue(BinaryReader reader, Field field) => reader.ReadByte() switch
    {
        0 => null,
        1 => reader.ReadString(),
        2 => reader.ReadBoolean(),
        3 => reader.ReadByte(),
        4 => reader.ReadSByte(),
        5 => reader.ReadInt16(),
        6 => reader.ReadUInt16(),
        7 => reader.ReadInt32(),
        8 => reader.ReadUInt32(),
        9 => reader.ReadInt64(),
        10 => reader.ReadUInt64(),
        11 => reader.ReadDecimal(),
        12 => reader.ReadSingle(),
        13 => reader.ReadDouble(),
        14 => DateTime.FromBinary(reader.ReadInt64()),
        15 => new DateTimeOffset(reader.ReadInt64(), new TimeSpan(reader.ReadInt64())),
        16 => new Guid(reader.ReadBytes(16)),
        17 => ReadEnum(reader, field),
        _ => throw Invalid()
    };

    private static object ReadEnum(BinaryReader reader, Field field)
    {
        var name = reader.ReadString();
        var type = (field as IEnumTypeField)?.EnumType ?? Nullable.GetUnderlyingType(field.ValueType) ?? field.ValueType;
        if (!type.IsEnum || type.FullName != name)
            throw Invalid();
        return Enum.ToObject(type, ReadValue(reader, field) ?? throw Invalid());
    }
}
