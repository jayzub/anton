    /// </summary>
    protected bool lookupAccessMode;

    internal bool keysetPagingActive;
    internal KeysetSortColumn[]? keysetSortColumns;
    internal byte[]? keysetRequestFingerprint;
    internal object?[]? keysetBoundaryValues;
    internal bool keysetHasMoreRows;

    /// <summary>
    /// Gets the list of list behaviors.
    /// </summary>
        if (DistinctFields != null)
            return DistinctFields.Contains(field);

        if (keysetPagingActive && IsKeysetField(field))
            return true;

        var mode = field.MinSelectLevel;

        if (mode == SelectLevel.Always)
    /// </summary>
    public IDictionary<string, object?> StateBag { get; } = new Dictionary<string, object?>();

    internal void ResetKeysetState()
    {
        keysetPagingActive = false;
        keysetSortColumns = null;
        keysetRequestFingerprint = null;
        keysetBoundaryValues = null;
        keysetHasMoreRows = false;
    }

    internal void InitializeKeysetPagination()
    {
        var hasToken = Request.PageToken is not null;
        var preconditionsMet = Request.Take > 0 &&
            Request.Skip == 0 &&
            Request.DistinctFields == null &&
            Row is IIdRow;

        if (!preconditionsMet)
        {
            if (hasToken)
                throw KeysetPaginationHelper.InvalidTokenError("Keyset pagination preconditions are not satisfied.");
            return;
        }

        keysetPagingActive = true;
        keysetSortColumns = ResolveEffectiveKeysetSort();
    }

    internal void FinalizeKeysetPreparation(SqlQuery query)
    {
        if (!keysetPagingActive || keysetSortColumns is null)
            return;

        EnsureKeysetColumnsSelected(query);

        var resolvedExpressions = new string[keysetSortColumns.Length];
        for (var i = 0; i < keysetSortColumns.Length; i++)
            resolvedExpressions[i] = ResolveKeysetFieldExpression(keysetSortColumns[i].Field, query);

        keysetRequestFingerprint = KeysetPaginationHelper.ComputeRequestFingerprint(
            typeof(TRow), keysetSortColumns, resolvedExpressions, Request);

        if (Request.PageToken is not null)
        {
            keysetBoundaryValues = KeysetPaginationHelper.DecodeAndValidateToken(
                Request.PageToken, keysetRequestFingerprint, keysetSortColumns);
        }
    }

    internal KeysetSortColumn[] ResolveEffectiveKeysetSort()
    {
        var idField = ((IIdRow)Row).GetIdField();
        var rawSort = Request.Sort is { Length: > 0 } ? Request.Sort : GetNativeSort();
        var result = new List<KeysetSortColumn>((rawSort?.Length ?? 0) + 1);
        var seen = new HashSet<Field>();

        if (rawSort is not null)
        {
            foreach (var sortBy in rawSort)
            {
                if (sortBy is null || string.IsNullOrWhiteSpace(sortBy.Field))
                    continue;

                var fieldName = sortBy.Field.Trim();
                var field = Row.FindField(fieldName) ?? Row.FindFieldByPropertyName(fieldName);
                if (field is null)
                    continue;

                if (field.Flags.HasFlag(FieldFlags.NotMapped))
                    continue;

                var sortable = field.GetAttribute<SortableAttribute>();
                if (sortable is not null && !sortable.Value)
                    continue;

                if (seen.Add(field))
                    result.Add(new KeysetSortColumn(field, sortBy.Descending));
            }
        }

        if (seen.Add(idField))
            result.Add(new KeysetSortColumn(idField, Descending: false));

        return [.. result];
    }

    internal bool IsKeysetField(Field field)
    {
        if (keysetSortColumns is null)
            return false;

        foreach (var col in keysetSortColumns)
        {
            if (ReferenceEquals(col.Field, field))
                return true;
        }

        return false;
    }

    internal string ResolveKeysetFieldExpression(Field field, SqlQuery query)
    {
        if (MapFieldExpression(field, query) is string mapped)
        {
            query.EnsureJoinsInExpression(mapped);
            return mapped;
        }

        if (((IGetExpressionByName)query).GetExpression(field.Name) is string selected)
        {
            query.EnsureJoinsInExpression(selected);
            return selected;
        }

        query.EnsureJoinsInExpression(field.Expression);
        return field.Expression;
    }

    internal void EnsureKeysetColumnsSelected(SqlQuery query)
    {
        if (!keysetPagingActive || keysetSortColumns is null)
            return;

        var columns = (IList<SqlQuery.Column>)((ISqlQueryExtensible)query).Columns;
        foreach (var col in keysetSortColumns)
        {
            var existingIndex = -1;
            for (var i = 0; i < columns.Count; i++)
            {
                if (ReferenceEquals(columns[i].IntoField, col.Field) ||
                    string.Equals(columns[i].ColumnName, col.Field.Name, StringComparison.OrdinalIgnoreCase))
                {
                    existingIndex = i;
                    break;
                }
            }

            if (existingIndex < 0)
            {
                SelectField(query, col.Field);
            }
            else if (MapFieldExpression(col.Field, query) is string mapped &&
                     !string.Equals(columns[existingIndex].Expression, mapped, StringComparison.Ordinal))
            {
                query.EnsureJoinsInExpression(mapped);
                columns[existingIndex] = new SqlQuery.Column(
                    mapped, columns[existingIndex].ColumnName, columns[existingIndex].IntoRowIndex, columns[existingIndex].IntoField);
            }
        }
    }

    internal int GetEffectiveQueryTake()
    {
        if (!keysetPagingActive)
            return Request.Take;

        return Request.Take < int.MaxValue ? Request.Take + 1 : int.MaxValue;
    }

    internal void ApplyKeysetContinuationOrder(SqlQuery query)
    {
        if (keysetSortColumns is null)
            return;

        foreach (var col in keysetSortColumns)
        {
            var expr = ResolveKeysetFieldExpression(col.Field, query);
            query.OrderBy(expr, col.Descending);
        }
    }

    internal void ApplyKeysetSeekFilter(SqlQuery query)
    {
        if (!keysetPagingActive || keysetBoundaryValues is null || keysetSortColumns is null)
            return;

        var seekCriteria = KeysetPaginationHelper.BuildSeekCriteria(
            query,
            Connection.GetDialect(),
            keysetSortColumns,
            keysetBoundaryValues,
            ResolveKeysetFieldExpression);

        var sb = new StringBuilder();
        seekCriteria.ToString(sb, query);
        query.seekFilter = sb.ToString();
    }

    internal bool TryAddEntityWithKeysetProbe(TRow clone)
    {
        if (!keysetPagingActive)
        {
            Response.Entities.Add(clone);
            return true;
        }

        if (Response.Entities.Count < Request.Take)
        {
            Response.Entities.Add(clone);
            return true;
        }

        keysetHasMoreRows = true;
        return false;
    }

    internal void CompleteKeysetPagination()
    {
        if (!keysetPagingActive)
            return;

        if (Response.Entities.Count > Request.Take)
        {
            keysetHasMoreRows = true;
            Response.Entities.RemoveRange(Request.Take, Response.Entities.Count - Request.Take);
        }

        Response.Take = Request.Take;
        if (Request.PageToken is not null)
            Response.Skip = 0;

        if (keysetHasMoreRows && Response.Entities.Count > 0 && keysetSortColumns is not null && keysetRequestFingerprint is not null)
        {
            var boundaryEntity = Response.Entities[^1];
            Response.NextPageToken = KeysetPaginationHelper.EncodeToken(
                keysetRequestFingerprint, keysetSortColumns, boundaryEntity);
        }
        else
        {
            Response.NextPageToken = null;
        }
    }

    IRow IListRequestHandler.Row => Row;
    ListRequest IListRequestHandler.Request => Request;
    IListResponse IListRequestHandler.Response => Response;
