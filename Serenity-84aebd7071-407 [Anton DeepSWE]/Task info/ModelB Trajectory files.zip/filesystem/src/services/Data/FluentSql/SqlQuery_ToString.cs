    int ISqlQuery.Take => take;
    ISqlQuery? ISqlQuery.UnionQuery => unionQuery;
    SqlUnionType ISqlQuery.UnionType => unionType;
    string? ISqlQuery.Where => seekFilter == null
        ? where?.ToString()
        : (where == null || where.Length == 0 ? seekFilter : where + " AND " + seekFilter);

    /// <summary>
    ///   Formats SQL Query as string. If paging is used and skip requested, multiple queries 

        var orderBy = query.OrderBy.ToArray();

        var baseWhere = query is SqlQuery sqlQuery ? sqlQuery.where?.ToString() : query.Where;
        string? extraWhere = (query as SqlQuery)?.seekFilter;

        bool useSkipKeyword = skip > 0 && dialect.CanUseSkipKeyword;
        bool useOffset = (skip > 0 || (take > 0 && !dialect.CanUseSkipKeyword && dialect.UseRowNum)) && 
                sb.Append(query.From);
            }

            if (extraWhere != null || !string.IsNullOrEmpty(baseWhere))
            {
                sb.Append(SqlKeywords.Where);

                if (!string.IsNullOrEmpty(baseWhere))
                    sb.Append(baseWhere);

                if (extraWhere != null)
                {
                    if (!string.IsNullOrEmpty(baseWhere))
                        sb.Append(" AND ");
                    sb.Append(extraWhere);
                }
                check.Append(')');

                // determine this statement as filter for next query
                extraWhere = extraWhere == null ? check.ToString() : extraWhere + " AND " + check;
            }
        }

