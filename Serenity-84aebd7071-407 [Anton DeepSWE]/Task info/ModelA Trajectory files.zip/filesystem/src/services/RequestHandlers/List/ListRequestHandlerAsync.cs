        {
            Response.TotalCount = await Query.ForEachAsync(Connection, delegate ()
            {
                if (!ProcessKeysetRow())
                    return;

                var clone = ProcessEntity(Row.Clone());
                if (clone == null)
                    return;
        };

        Row = new TRow();
        InitializeKeysetPagination();

        var query = CreateQuery();
        Query = query;

        await PrepareQueryAsync(query, cancellationToken).ConfigureAwait(false);

        SelectKeysetFields();

        if (DistinctFields == null)
            ApplyKeyOrder(query);


        await OnBeforeExecuteQueryAsync(cancellationToken).ConfigureAwait(false);

        ApplyKeysetPagination();

        if (DistinctFields == null || DistinctFields.Length > 0)
        {
            await ExecuteQueryAsync(cancellationToken).ConfigureAwait(false);
        }

        Response.SetSkipTakeTotal(query);
        CompleteKeysetPagination();

        await OnAfterExecuteQueryAsync(cancellationToken).ConfigureAwait(false);

