        bool useRowNumber = skip > 0 && !useSkipKeyword && !useOffset && !useRowNum && dialect.CanUseRowNumber;
        bool useSecondQuery = skip > 0 && !useSkipKeyword && !useRowNum && !useOffset && !useRowNumber;

        void appendFromWhereOrderByGroupByHaving(string? extraWhere, bool includeOrderBy, bool forCount = false)
        {
            var where = forCount ? (query as SqlQuery)?.WhereForCount ?? query.Where : query.Where;

            if (!string.IsNullOrEmpty(query.From))
            {
                sb.Append(SqlKeywords.From);
                sb.Append(query.From);
            }

            if (extraWhere != null || !string.IsNullOrEmpty(where))
            {
                sb.Append(SqlKeywords.Where);

                if (!string.IsNullOrEmpty(where))
                    sb.Append(where);

                if (extraWhere != null)
                {
                    if (!string.IsNullOrEmpty(where))
                        sb.Append(" AND ");
                    sb.Append(extraWhere);
                }
                sb.Append(" 1 as x__alias__x ");
            }

            appendFromWhereOrderByGroupByHaving(null, false, forCount: true);

            if (query.Distinct || (!string.IsNullOrEmpty(query.GroupBy)))
            {
