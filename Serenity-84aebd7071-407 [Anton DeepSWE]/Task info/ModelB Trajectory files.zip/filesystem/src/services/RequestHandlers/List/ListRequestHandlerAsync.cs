                        Response.Values!.Add(field.AsObject(clone)!);
                }
                else
                    TryAddEntityWithKeysetProbe(clone);
            }, cancellationToken).ConfigureAwait(false);
        }
        catch (Exception exception)
        StateBag.Clear();
        lookupAccessMode = false;
        ignoredEqualityFilters = null;
        ResetKeysetState();
        Connection = connection ?? throw new ArgumentNullException(nameof(connection));
        Request = request ?? throw new ArgumentNullException(nameof(request));
        await ValidateRequestAsync(cancellationToken).ConfigureAwait(false);
        if (DistinctFields != null)
            Response.Values = [];

        InitializeKeysetPagination();

        await PrepareQueryAsync(query, cancellationToken).ConfigureAwait(false);
        FinalizeKeysetPreparation(query);

        var isContinuation = keysetBoundaryValues is not null;
        if (DistinctFields == null && !isContinuation)
            ApplyKeyOrder(query);

        query.ApplySkipTakeAndCount(request.Skip, GetEffectiveQueryTake(),
            request.ExcludeTotalCount || DistinctFields != null);

        ApplyContainsText(query, request.ContainsText);

        if (DistinctFields == null)
        {
            if (isContinuation)
                ApplyKeysetContinuationOrder(query);
            else
                ApplySort(query);
        }

        await ApplyFiltersAsync(query, cancellationToken).ConfigureAwait(false);
        ApplyKeysetSeekFilter(query);

        await OnBeforeExecuteQueryAsync(cancellationToken).ConfigureAwait(false);

        }

        Response.SetSkipTakeTotal(query);
        CompleteKeysetPagination();

        await OnAfterExecuteQueryAsync(cancellationToken).ConfigureAwait(false);

