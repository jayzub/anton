    private int skip;
    private int take;
    private StringBuilder? where;
    internal string? seekFilter;
    private int intoIndex = -1;
    private List<object> into = [];
    private SqlQuery? unionQuery;
