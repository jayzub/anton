    /// </summary>
    public List<object?>? Values { get; set; }

    /// <summary>
    /// Opaque continuation token, or null when there are no more pages.
    /// </summary>
    public string? NextPageToken { get; set; }

    /// <inheritdoc/>
    public int TotalCount { get; set; }

