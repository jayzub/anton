            forJson = forJson,
            unionQuery = unionQuery,
            unionType = unionType,
            nextAutoParam = nextAutoParam,
            seekFilter = seekFilter
        };

        Column s;
