    [JsonConverter(typeof(JsonConverters.NullAsDefaultJsonConverter))]
    public int Take { get; set; }

    /// <summary>
    /// Optional continuation token for server-side keyset pagination.
    /// </summary>
    public string? PageToken { get; set; }

    /// <summary>
    /// Columns to sort returned records by
    /// </summary>
