using Newtonsoft.Json.Linq;
using System.Security.Cryptography;

namespace Serenity.Services;

public abstract partial class ListRequestHandlerBase<TRow, TListRequest, TListResponse>
{
    private List<(Field Field, bool Descending)>? keysetSort;
    private string[]? keysetExpressions;
    private byte[]? keysetFingerprint;
    private object?[]? keysetBoundary;
    private int keysetRowsRead;
    private bool keysetHasMore;

    private protected void InitializeKeysetPagination()
    {
        keysetSort = null;
        keysetExpressions = null;
        keysetFingerprint = null;
        keysetBoundary = null;
        keysetRowsRead = 0;
        keysetHasMore = false;

        if (Request.Take <= 0 || Request.Skip != 0 || Request.DistinctFields != null || Row is not IIdRow)
        {
            if (Request.PageToken != null)
                throw ListPageToken.Invalid();
            return;
        }

        var sort = new List<(Field Field, bool Descending)>();
        foreach (var item in Request.Sort is { Length: > 0 } ? Request.Sort : GetNativeSort() ?? [])
        {
            var name = item.Field.TrimToNull();
            if (name == null)
                continue;
            var field = Row.FindField(name) ?? Row.FindFieldByPropertyName(name);
            // These sorts are also ignored by ApplySortBy.
            if (field is null || field.Flags.HasFlag(FieldFlags.NotMapped) ||
                field.GetAttribute<SortableAttribute>()?.Value == false)
                continue;
            if (!sort.Any(x => ReferenceEquals(x.Field, field)))
                sort.Add((field, item.Descending));
        }

        var id = ((IIdRow)Row).GetIdField();
        if (!sort.Any(x => ReferenceEquals(x.Field, id)))
            sort.Add((id, false));

        // Column selection exclusions can be overridden, but read permissions cannot.
        if (sort.Any(x => !AllowSelectField(x.Field)))
        {
            if (Request.PageToken != null)
                throw ListPageToken.Invalid();
            return;
        }
        keysetSort = sort;
    }

    private protected void SelectKeysetFields()
    {
        if (keysetSort == null)
            return;

        var ext = (ISqlQueryExtensible)Query;
        foreach (var (field, _) in keysetSort)
            if (ext.GetSelectIntoIndex(field) < 0)
                SelectField(Query, field);

        // Use exactly the selected expressions, including any localization rewrites.
        keysetExpressions = keysetSort.Select(x =>
            ext.Columns[ext.GetSelectIntoIndex(x.Field)].Expression).ToArray();
        var filters = new ListRequest
        {
            Criteria = Request.Criteria,
            EqualityFilter = Request.EqualityFilter,
            ContainsText = Request.ContainsText,
            ContainsField = Request.ContainsField,
            IncludeDeleted = Request.IncludeDeleted
        };
        var signature = JObject.FromObject(new
        {
            Row = typeof(TRow).AssemblyQualifiedName,
            Dialect = Query.Dialect().ServerType,
            Sort = keysetSort.Select((x, i) => new { x.Field.Name, x.Descending, Expression = keysetExpressions[i] }),
            Filters = filters
        });
        keysetFingerprint = SHA256.HashData(Encoding.UTF8.GetBytes(Canonicalize(signature).ToString(Newtonsoft.Json.Formatting.None)));

        if (Request.PageToken != null)
            keysetBoundary = ListPageToken.Read(Request.PageToken, keysetFingerprint,
                keysetSort.Select(x => x.Field).ToArray());
    }

    private protected void ApplyKeysetPagination()
    {
        if (keysetSort == null)
            return;

        if (keysetBoundary != null)
        {
            // Do not change the native first-page ordering. On continuation, make
            // the canonical order explicit, including the unique ID tiebreaker.
            for (var i = keysetSort.Count - 1; i >= 0; i--)
                Query.OrderByFirst(keysetExpressions![i], keysetSort[i].Descending);

            Query.WhereForCount = ((ISqlQuery)Query).Where ?? "";
            Query.Where(BuildSeekCriteria(keysetBoundary));
            Query.Skip(0);
        }

        // Avoid overflow for an unbounded practical page size.
        Query.Take(Request.Take == int.MaxValue ? int.MaxValue : Request.Take + 1);
    }

    private BaseCriteria BuildSeekCriteria(object?[] values)
    {
        var nullsHigh = Query.Dialect().ServerType is nameof(ServerType.Postgres) or
            nameof(ServerType.Oracle) or nameof(ServerType.Firebird);
        BaseCriteria? seek = null;
        BaseCriteria? equal = null;
        for (var i = 0; i < keysetSort!.Count; i++)
        {
            var column = new Criteria(keysetSort[i].Field, keysetExpressions![i]);
            var descending = keysetSort[i].Descending;
            var nullsFirst = descending == nullsHigh;
            BaseCriteria? after;
            BaseCriteria same;
            if (values[i] == null)
            {
                after = nullsFirst ? column.IsNotNull() : null;
                same = column.IsNull();
            }
            else
            {
                var value = new ValueCriteria(values[i]);
                after = descending ? column < value : column > value;
                if (!nullsFirst)
                    after |= column.IsNull();
                same = column == value;
            }

            // No greater value exists after a NULL that sorts last, but later
            // sort columns can still advance within the group of NULLs.
            if (after is not null)
                seek |= equal & after;
            equal &= same;
        }
        return seek ?? new Criteria("1 = 0");
    }

    private protected bool ProcessKeysetRow()
    {
        if (keysetSort == null || keysetRowsRead++ < Request.Take)
            return true;

        keysetHasMore = true;
        return false;
    }

    private protected void CompleteKeysetPagination()
    {
        Response.NextPageToken = null;
        if (keysetSort == null)
            return;

        Response.Take = Request.Take;
        Response.Skip = 0;
        if (Response.Entities.Count == 0 || (!keysetHasMore && Response.Entities.Count <= Request.Take))
            return;

        if (Response.Entities.Count > Request.Take)
            Response.Entities.RemoveRange(Request.Take, Response.Entities.Count - Request.Take);
        var last = Response.Entities[^1];
        Response.NextPageToken = ListPageToken.Write(keysetFingerprint!,
            keysetSort.Select(x => x.Field.AsObject(last)).ToArray());
    }

    private static JToken Canonicalize(JToken token)
    {
        if (token is JObject obj)
            return new JObject(obj.Properties().OrderBy(x => x.Name, StringComparer.Ordinal)
                .Select(x => new JProperty(x.Name, Canonicalize(x.Value))));
        if (token is JArray array)
            return new JArray(array.Select(Canonicalize));
        return token.DeepClone();
    }
}
