using System.Buffers.Text;
using System.Collections;
using System.IO;
using System.Security.Cryptography;
using System.Text.Json;

namespace Serenity.Services;

internal readonly record struct KeysetSortColumn(Field Field, bool Descending);

internal static class KeysetPaginationHelper
{
    private const byte FormatVersion = 1;
    private const int FingerprintSize = 32;
    private const int IntegrityTagSize = 16;

    private static ReadOnlySpan<byte> IntegrityDomainPrefix =>
        "Serenity.KeysetPageToken.v1:"u8;

    private static readonly UTF8Encoding StrictUtf8 = new(
        encoderShouldEmitUTF8Identifier: false,
        throwOnInvalidBytes: true);

    private enum ValueTag : byte
    {
        Null = 0,
        BoolFalse = 1,
        BoolTrue = 2,
        SByte = 3,
        Byte = 4,
        Int16 = 5,
        UInt16 = 6,
        Int32 = 7,
        UInt32 = 8,
        Int64 = 9,
        UInt64 = 10,
        Single = 11,
        Double = 12,
        Decimal = 13,
        Char = 14,
        StringUtf8 = 15,
        StringUtf16 = 16,
        Guid = 17,
        DateTime = 18,
        DateTimeOffset = 19,
        DateOnly = 20,
        TimeOnly = 21,
        TimeSpan = 22,
        ByteArray = 23,
        Enum = 24
    }

    public static ValidationError InvalidTokenError(string message = "Invalid page token.") =>
        new("InvalidPageToken", nameof(ListRequest.PageToken), message);

    public static bool NullsSortFirstInAscending(ISqlDialect dialect)
    {
        ArgumentNullException.ThrowIfNull(dialect);

        if (dialect is PostgresDialect or OracleDialect or FirebirdDialect)
            return false;

        var serverType = dialect.ServerType;
        if (string.Equals(serverType, nameof(ServerType.Postgres), StringComparison.OrdinalIgnoreCase) ||
            string.Equals(serverType, "PostgreSQL", StringComparison.OrdinalIgnoreCase) ||
            string.Equals(serverType, nameof(ServerType.Oracle), StringComparison.OrdinalIgnoreCase) ||
            string.Equals(serverType, nameof(ServerType.Firebird), StringComparison.OrdinalIgnoreCase))
        {
            return false;
        }

        return true;
    }

    public static object? ExtractBoundaryValue(Field field, IRow entity)
    {
        var value = field.AsObject(entity);
        if (value is null)
            return null;

        if (!value.GetType().IsEnum)
        {
            var enumType = GetFieldEnumType(field);
            if (enumType is not null)
                return Enum.ToObject(enumType, value);
        }

        return value;
    }

    private static Type? GetFieldEnumType(Field field)
    {
        if (field is IEnumTypeField { EnumType.IsEnum: true } enumField)
            return enumField.EnumType;

        if (field.ValueType.IsEnum)
            return field.ValueType;

        if (Nullable.GetUnderlyingType(field.ValueType) is { IsEnum: true } underlyingEnum)
            return underlyingEnum;

        return null;
    }

    public static byte[] ComputeRequestFingerprint(
        Type rowType,
        ReadOnlySpan<KeysetSortColumn> effectiveSort,
        ReadOnlySpan<string> resolvedSortExpressions,
        ListRequest request)
    {
        using var ms = new MemoryStream(256);
        using var writer = new BinaryWriter(ms, Encoding.UTF8, leaveOpen: true);

        // 1. Entity row type
        writer.Write(rowType.FullName ?? rowType.Name);

        // 2. Effective sort order
        writer.Write(effectiveSort.Length);
        for (var i = 0; i < effectiveSort.Length; i++)
        {
            writer.Write(effectiveSort[i].Field.Name);
            writer.Write(effectiveSort[i].Descending);
            writer.Write(resolvedSortExpressions[i]);
        }

        // 3. Criteria
        if (request.Criteria is null || request.Criteria.IsEmpty)
        {
            writer.Write(false);
        }
        else
        {
            writer.Write(true);
            var sb = new StringBuilder();
            var collector = new FingerprintCriteriaParams();
            request.Criteria.ToString(sb, collector);
            writer.Write(sb.ToString());
            writer.Write(collector.Values.Count);
            foreach (var val in collector.Values)
                WriteCanonicalFilterValue(writer, val);
        }

        // 4. EqualityFilter
        if (request.EqualityFilter is null || request.EqualityFilter.Count == 0)
        {
            writer.Write(0);
        }
        else
        {
            var keys = new string[request.EqualityFilter.Count];
            var idx = 0;
            foreach (var key in request.EqualityFilter.Keys)
                keys[idx++] = key;
            Array.Sort(keys, StringComparer.Ordinal);

            writer.Write(keys.Length);
            foreach (var key in keys)
            {
                writer.Write(key);
                WriteCanonicalFilterValue(writer, request.EqualityFilter[key]);
            }
        }

        // 5. ContainsText
        WriteNullableString(writer, request.ContainsText);

        // 6. ContainsField
        WriteNullableString(writer, request.ContainsField);

        // 7. IncludeDeleted
        writer.Write(request.IncludeDeleted);

        writer.Flush();
        return SHA256.HashData(ms.GetBuffer().AsSpan(0, (int)ms.Length));
    }

    private static void WriteNullableString(BinaryWriter writer, string? value)
    {
        if (value is null)
        {
            writer.Write(false);
            return;
        }

        writer.Write(true);
        writer.Write(value);
    }

    private static void WriteCanonicalFilterValue(BinaryWriter writer, object? value)
    {
        if (value is Newtonsoft.Json.Linq.JValue jValue)
            value = jValue.Value;

        if (value is null || value is DBNull)
        {
            writer.Write((byte)0);
            return;
        }

        if (value is JsonElement je)
        {
            WriteCanonicalJsonElement(writer, je);
            return;
        }

        if (value is Newtonsoft.Json.Linq.JArray jArray)
        {
            writer.Write((byte)4);
            writer.Write(jArray.Count);
            foreach (var item in jArray)
                WriteCanonicalFilterValue(writer, item);
            return;
        }

        if (value is Newtonsoft.Json.Linq.JObject jObject)
        {
            var props = jObject.Properties().OrderBy(p => p.Name, StringComparer.Ordinal).ToList();
            writer.Write((byte)5);
            writer.Write(props.Count);
            foreach (var prop in props)
            {
                writer.Write(prop.Name);
                WriteCanonicalFilterValue(writer, prop.Value);
            }
            return;
        }

        if (value is bool b)
        {
            writer.Write((byte)1);
            writer.Write(b);
            return;
        }

        if (value is string s)
        {
            writer.Write((byte)2);
            writer.Write(s);
            return;
        }

        if (value is Enum)
        {
            var underlying = Convert.ChangeType(value, Enum.GetUnderlyingType(value.GetType()), CultureInfo.InvariantCulture);
            WriteCanonicalNumber(writer, underlying!);
            return;
        }

        if (value is sbyte or byte or short or ushort or int or uint or long or ulong or float or double or decimal)
        {
            WriteCanonicalNumber(writer, value);
            return;
        }

        if (value is DateTime dt)
        {
            writer.Write((byte)6);
            writer.Write(dt.Ticks);
            writer.Write((byte)dt.Kind);
            return;
        }

        if (value is DateTimeOffset dto)
        {
            writer.Write((byte)7);
            writer.Write(dto.Ticks);
            writer.Write(dto.Offset.Ticks);
            return;
        }

        if (value is Guid g)
        {
            writer.Write((byte)8);
            writer.Write(g.ToByteArray());
            return;
        }

        if (value is DateOnly d)
        {
            writer.Write((byte)9);
            writer.Write(d.DayNumber);
            return;
        }

        if (value is TimeOnly t)
        {
            writer.Write((byte)10);
            writer.Write(t.Ticks);
            return;
        }

        if (value is TimeSpan ts)
        {
            writer.Write((byte)11);
            writer.Write(ts.Ticks);
            return;
        }

        if (value is byte[] bytes)
        {
            writer.Write((byte)12);
            writer.Write(bytes.Length);
            writer.Write(bytes);
            return;
        }

        if (value is IEnumerable enumerable)
        {
            var items = new List<object?>();
            foreach (var item in enumerable)
                items.Add(item);
            writer.Write((byte)4);
            writer.Write(items.Count);
            foreach (var item in items)
                WriteCanonicalFilterValue(writer, item);
            return;
        }

        writer.Write((byte)13);
        writer.Write(value.GetType().FullName ?? string.Empty);
        writer.Write(Convert.ToString(value, CultureInfo.InvariantCulture) ?? string.Empty);
    }

    private static void WriteCanonicalJsonElement(BinaryWriter writer, JsonElement element)
    {
        switch (element.ValueKind)
        {
            case JsonValueKind.Null:
            case JsonValueKind.Undefined:
                writer.Write((byte)0);
                break;

            case JsonValueKind.True:
                writer.Write((byte)1);
                writer.Write(true);
                break;

            case JsonValueKind.False:
                writer.Write((byte)1);
                writer.Write(false);
                break;

            case JsonValueKind.String:
                writer.Write((byte)2);
                writer.Write(element.GetString()!);
                break;

            case JsonValueKind.Number:
                if (element.TryGetDecimal(out var dec))
                    WriteCanonicalDecimal(writer, dec);
                else
                    WriteCanonicalDouble(writer, element.GetDouble());
                break;

            case JsonValueKind.Array:
                writer.Write((byte)4);
                writer.Write(element.GetArrayLength());
                foreach (var item in element.EnumerateArray())
                    WriteCanonicalJsonElement(writer, item);
                break;

            case JsonValueKind.Object:
                var props = new List<JsonProperty>();
                foreach (var prop in element.EnumerateObject())
                    props.Add(prop);
                props.Sort((a, b) => string.CompareOrdinal(a.Name, b.Name));
                writer.Write((byte)5);
                writer.Write(props.Count);
                foreach (var prop in props)
                {
                    writer.Write(prop.Name);
                    WriteCanonicalJsonElement(writer, prop.Value);
                }
                break;
        }
    }

    private static void WriteCanonicalNumber(BinaryWriter writer, object value)
    {
        switch (value)
        {
            case decimal dec:
                WriteCanonicalDecimal(writer, dec);
                return;
            case sbyte v:
                WriteCanonicalDecimal(writer, v);
                return;
            case byte v:
                WriteCanonicalDecimal(writer, v);
                return;
            case short v:
                WriteCanonicalDecimal(writer, v);
                return;
            case ushort v:
                WriteCanonicalDecimal(writer, v);
                return;
            case int v:
                WriteCanonicalDecimal(writer, v);
                return;
            case uint v:
                WriteCanonicalDecimal(writer, v);
                return;
            case long v:
                WriteCanonicalDecimal(writer, v);
                return;
            case ulong v:
                WriteCanonicalDecimal(writer, v);
                return;
            case float f when float.IsFinite(f) && TryDoubleToDecimal(f, out var fDec):
                WriteCanonicalDecimal(writer, fDec);
                return;
            case double d when double.IsFinite(d) && TryDoubleToDecimal(d, out var dDec):
                WriteCanonicalDecimal(writer, dDec);
                return;
            case float f2:
                WriteCanonicalDouble(writer, f2);
                return;
            case double d2:
                WriteCanonicalDouble(writer, d2);
                return;
        }
    }

    private static bool TryDoubleToDecimal(double value, out decimal result)
    {
        return decimal.TryParse(
            value.ToString("R", CultureInfo.InvariantCulture),
            NumberStyles.Float,
            CultureInfo.InvariantCulture,
            out result);
    }

    private static void WriteCanonicalDecimal(BinaryWriter writer, decimal value)
    {
        writer.Write((byte)3);
        var s = value.ToString(CultureInfo.InvariantCulture);
        if (s.Contains('.'))
            s = s.TrimEnd('0').TrimEnd('.');
        if (s == "-0")
            s = "0";
        writer.Write(s);
    }

    private static void WriteCanonicalDouble(BinaryWriter writer, double value)
    {
        writer.Write((byte)14);
        writer.Write(BitConverter.DoubleToInt64Bits(value));
    }

    public static string EncodeToken(
        ReadOnlySpan<byte> requestFingerprint,
        ReadOnlySpan<KeysetSortColumn> effectiveSort,
        IRow boundaryEntity)
    {
        using var ms = new MemoryStream(128);
        using (var writer = new BinaryWriter(ms, Encoding.UTF8, leaveOpen: true))
        {
            writer.Write(FormatVersion);
            writer.Write(requestFingerprint);
            writer.Write(effectiveSort.Length);

            foreach (var col in effectiveSort)
            {
                var value = ExtractBoundaryValue(col.Field, boundaryEntity);
                WriteBoundaryValue(writer, value);
            }
        }

        var payloadLength = (int)ms.Length;
        Span<byte> fullDigest = stackalloc byte[32];
        ComputeIntegrityHash(ms.GetBuffer().AsSpan(0, payloadLength), fullDigest);
        ms.Write(fullDigest[..IntegrityTagSize]);

        return Base64Url.EncodeToString(ms.GetBuffer().AsSpan(0, (int)ms.Length));
    }

    public static object?[] DecodeAndValidateToken(
        string token,
        ReadOnlySpan<byte> expectedFingerprint,
        ReadOnlySpan<KeysetSortColumn> effectiveSort)
    {
        if (string.IsNullOrEmpty(token))
            throw InvalidTokenError();

        // Enforce strict unpadded RFC 4648 Section 5 Base64URL alphabet
        foreach (var ch in token)
        {
            var isValid = (ch >= 'A' && ch <= 'Z') ||
                          (ch >= 'a' && ch <= 'z') ||
                          (ch >= '0' && ch <= '9') ||
                          ch == '-' || ch == '_';
            if (!isValid)
                throw InvalidTokenError();
        }

        byte[] rawBytes;
        try
        {
            rawBytes = Base64Url.DecodeFromChars(token);
        }
        catch (FormatException)
        {
            throw InvalidTokenError();
        }

        // Reject any non-canonical unused trailing sextet bit mutations
        if (!string.Equals(Base64Url.EncodeToString(rawBytes), token, StringComparison.Ordinal))
            throw InvalidTokenError();

        const int minLength = 1 + FingerprintSize + sizeof(int) + IntegrityTagSize;
        if (rawBytes.Length < minLength)
            throw InvalidTokenError();

        var payloadLength = rawBytes.Length - IntegrityTagSize;
        var payloadSpan = rawBytes.AsSpan(0, payloadLength);
        var actualTag = rawBytes.AsSpan(payloadLength, IntegrityTagSize);

        Span<byte> computedFullDigest = stackalloc byte[32];
        ComputeIntegrityHash(payloadSpan, computedFullDigest);
        if (!CryptographicOperations.FixedTimeEquals(actualTag, computedFullDigest[..IntegrityTagSize]))
            throw InvalidTokenError();

        try
        {
            using var ms = new MemoryStream(rawBytes, 0, payloadLength, writable: false);
            using var reader = new BinaryReader(ms, Encoding.UTF8, leaveOpen: false);

            var version = reader.ReadByte();
            if (version != FormatVersion)
                throw InvalidTokenError();

            var tokenFingerprint = reader.ReadBytes(FingerprintSize);
            if (tokenFingerprint.Length != FingerprintSize ||
                !CryptographicOperations.FixedTimeEquals(tokenFingerprint, expectedFingerprint))
            {
                throw InvalidTokenError("Page token does not match the current query parameters.");
            }

            var count = reader.ReadInt32();
            if (count != effectiveSort.Length)
                throw InvalidTokenError();

            var values = new object?[count];
            for (var i = 0; i < count; i++)
                values[i] = ReadBoundaryValue(reader, effectiveSort[i].Field);

            if (ms.Position != payloadLength)
                throw InvalidTokenError();

            return values;
        }
        catch (ValidationError)
        {
            throw;
        }
        catch (Exception)
        {
            throw InvalidTokenError();
        }
    }

    private static void ComputeIntegrityHash(ReadOnlySpan<byte> payload, Span<byte> destination)
    {
        using var sha = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
        sha.AppendData(IntegrityDomainPrefix);
        sha.AppendData(payload);
        sha.GetHashAndReset(destination);
    }

    private static void WriteBoundaryValue(BinaryWriter writer, object? value)
    {
        if (value is null || value is DBNull)
        {
            writer.Write((byte)ValueTag.Null);
            return;
        }

        if (value is Enum)
        {
            var enumType = value.GetType();
            var underlying = Convert.ChangeType(value, Enum.GetUnderlyingType(enumType), CultureInfo.InvariantCulture)!;
            writer.Write((byte)ValueTag.Enum);
            writer.Write(enumType.AssemblyQualifiedName ?? enumType.FullName ?? string.Empty);
            WriteBoundaryValue(writer, underlying);
            return;
        }

        switch (value)
        {
            case bool b:
                writer.Write((byte)(b ? ValueTag.BoolTrue : ValueTag.BoolFalse));
                break;

            case sbyte v:
                writer.Write((byte)ValueTag.SByte);
                writer.Write(v);
                break;

            case byte v:
                writer.Write((byte)ValueTag.Byte);
                writer.Write(v);
                break;

            case short v:
                writer.Write((byte)ValueTag.Int16);
                writer.Write(v);
                break;

            case ushort v:
                writer.Write((byte)ValueTag.UInt16);
                writer.Write(v);
                break;

            case int v:
                writer.Write((byte)ValueTag.Int32);
                writer.Write(v);
                break;

            case uint v:
                writer.Write((byte)ValueTag.UInt32);
                writer.Write(v);
                break;

            case long v:
                writer.Write((byte)ValueTag.Int64);
                writer.Write(v);
                break;

            case ulong v:
                writer.Write((byte)ValueTag.UInt64);
                writer.Write(v);
                break;

            case float v:
                writer.Write((byte)ValueTag.Single);
                writer.Write(BitConverter.SingleToInt32Bits(v));
                break;

            case double v:
                writer.Write((byte)ValueTag.Double);
                writer.Write(BitConverter.DoubleToInt64Bits(v));
                break;

            case decimal v:
                writer.Write((byte)ValueTag.Decimal);
                var bits = decimal.GetBits(v);
                writer.Write(bits[0]);
                writer.Write(bits[1]);
                writer.Write(bits[2]);
                writer.Write(bits[3]);
                break;

            case char v:
                writer.Write((byte)ValueTag.Char);
                writer.Write((ushort)v);
                break;

            case string s:
                WriteStringValue(writer, s);
                break;

            case Guid g:
                writer.Write((byte)ValueTag.Guid);
                Span<byte> guidBytes = stackalloc byte[16];
                g.TryWriteBytes(guidBytes);
                writer.Write(guidBytes);
                break;

            case DateTime dt:
                writer.Write((byte)ValueTag.DateTime);
                writer.Write(dt.Ticks);
                writer.Write((byte)dt.Kind);
                break;

            case DateTimeOffset dto:
                writer.Write((byte)ValueTag.DateTimeOffset);
                writer.Write(dto.Ticks);
                writer.Write(dto.Offset.Ticks);
                break;

            case DateOnly d:
                writer.Write((byte)ValueTag.DateOnly);
                writer.Write(d.DayNumber);
                break;

            case TimeOnly t:
                writer.Write((byte)ValueTag.TimeOnly);
                writer.Write(t.Ticks);
                break;

            case TimeSpan ts:
                writer.Write((byte)ValueTag.TimeSpan);
                writer.Write(ts.Ticks);
                break;

            case byte[] bytes:
                writer.Write((byte)ValueTag.ByteArray);
                writer.Write(bytes.Length);
                writer.Write(bytes);
                break;

            default:
                WriteStringValue(writer, Convert.ToString(value, CultureInfo.InvariantCulture) ?? string.Empty);
                break;
        }
    }

    private static void WriteStringValue(BinaryWriter writer, string value)
    {
        try
        {
            var utf8Bytes = StrictUtf8.GetBytes(value);
            writer.Write((byte)ValueTag.StringUtf8);
            writer.Write(utf8Bytes.Length);
            writer.Write(utf8Bytes);
        }
        catch (EncoderFallbackException)
        {
            writer.Write((byte)ValueTag.StringUtf16);
            writer.Write(value.Length);
            foreach (var ch in value)
                writer.Write((ushort)ch);
        }
    }

    private static object? ReadBoundaryValue(BinaryReader reader, Field field)
    {
        var tag = (ValueTag)reader.ReadByte();
        switch (tag)
        {
            case ValueTag.Null:
                return null;

            case ValueTag.BoolFalse:
                return false;

            case ValueTag.BoolTrue:
                return true;

            case ValueTag.SByte:
                return reader.ReadSByte();

            case ValueTag.Byte:
                return reader.ReadByte();

            case ValueTag.Int16:
                return reader.ReadInt16();

            case ValueTag.UInt16:
                return reader.ReadUInt16();

            case ValueTag.Int32:
                return reader.ReadInt32();

            case ValueTag.UInt32:
                return reader.ReadUInt32();

            case ValueTag.Int64:
                return reader.ReadInt64();

            case ValueTag.UInt64:
                return reader.ReadUInt64();

            case ValueTag.Single:
                return BitConverter.Int32BitsToSingle(reader.ReadInt32());

            case ValueTag.Double:
                return BitConverter.Int64BitsToDouble(reader.ReadInt64());

            case ValueTag.Decimal:
                return new decimal([
                    reader.ReadInt32(),
                    reader.ReadInt32(),
                    reader.ReadInt32(),
                    reader.ReadInt32()
                ]);

            case ValueTag.Char:
                return (char)reader.ReadUInt16();

            case ValueTag.StringUtf8:
            {
                var len = reader.ReadInt32();
                if (len < 0 || len > reader.BaseStream.Length - reader.BaseStream.Position)
                    throw InvalidTokenError();
                var bytes = reader.ReadBytes(len);
                if (bytes.Length != len)
                    throw InvalidTokenError();
                return StrictUtf8.GetString(bytes);
            }

            case ValueTag.StringUtf16:
            {
                var charCount = reader.ReadInt32();
                if (charCount < 0 || (long)charCount * 2 > reader.BaseStream.Length - reader.BaseStream.Position)
                    throw InvalidTokenError();
                var chars = new char[charCount];
                for (var i = 0; i < charCount; i++)
                    chars[i] = (char)reader.ReadUInt16();
                return new string(chars);
            }

            case ValueTag.Guid:
            {
                var guidBytes = reader.ReadBytes(16);
                if (guidBytes.Length != 16)
                    throw InvalidTokenError();
                return new Guid(guidBytes);
            }

            case ValueTag.DateTime:
            {
                var ticks = reader.ReadInt64();
                var kind = (DateTimeKind)reader.ReadByte();
                if (kind is not (DateTimeKind.Unspecified or DateTimeKind.Utc or DateTimeKind.Local))
                    throw InvalidTokenError();
                return new DateTime(ticks, kind);
            }

            case ValueTag.DateTimeOffset:
            {
                var ticks = reader.ReadInt64();
                var offsetTicks = reader.ReadInt64();
                return new DateTimeOffset(ticks, TimeSpan.FromTicks(offsetTicks));
            }

            case ValueTag.DateOnly:
                return DateOnly.FromDayNumber(reader.ReadInt32());

            case ValueTag.TimeOnly:
                return new TimeOnly(reader.ReadInt64());

            case ValueTag.TimeSpan:
                return TimeSpan.FromTicks(reader.ReadInt64());

            case ValueTag.ByteArray:
            {
                var len = reader.ReadInt32();
                if (len < 0 || len > reader.BaseStream.Length - reader.BaseStream.Position)
                    throw InvalidTokenError();
                var bytes = reader.ReadBytes(len);
                if (bytes.Length != len)
                    throw InvalidTokenError();
                return bytes;
            }

            case ValueTag.Enum:
            {
                var typeName = reader.ReadString();
                var rawUnderlying = ReadBoundaryValue(reader, field) ?? throw InvalidTokenError();
                var enumType = GetFieldEnumType(field) ??
                    (!string.IsNullOrEmpty(typeName) ? Type.GetType(typeName, throwOnError: false) : null);
                if (enumType is null || !enumType.IsEnum)
                    throw InvalidTokenError();
                return Enum.ToObject(enumType, rawUnderlying);
            }

            default:
                throw InvalidTokenError();
        }
    }

    public static BaseCriteria BuildSeekCriteria(
        SqlQuery query,
        ISqlDialect dialect,
        ReadOnlySpan<KeysetSortColumn> effectiveSort,
        ReadOnlySpan<object?> boundaryValues,
        Func<Field, SqlQuery, string> getFieldExpression)
    {
        var nullsSortFirstInAsc = NullsSortFirstInAscending(dialect);
        var count = effectiveSort.Length;
        var columnClauses = new (BaseCriteria? After, BaseCriteria Equal)[count];

        for (var i = 0; i < count; i++)
        {
            var col = effectiveSort[i];
            var expr = getFieldExpression(col.Field, query);
            var colCriteria = new Criteria(col.Field, expr);
            var nullsComeFirst = nullsSortFirstInAsc != col.Descending;
            var boundaryValue = boundaryValues[i];

            if (boundaryValue is null)
            {
                var after = nullsComeFirst ? colCriteria.IsNotNull() : null;
                var equal = colCriteria.IsNull();
                columnClauses[i] = (after, equal);
            }
            else
            {
                var param = query.AutoParam();
                query.AddParam(param.Name, boundaryValue);
                var paramCriteria = new ParamCriteria(param.Name);
                var cmpOp = col.Descending ? CriteriaOperator.LT : CriteriaOperator.GT;
                var strictCmp = new BinaryCriteria(colCriteria, cmpOp, paramCriteria);
                var after = nullsComeFirst ? strictCmp : (strictCmp | colCriteria.IsNull());
                var equal = new BinaryCriteria(colCriteria, CriteriaOperator.EQ, paramCriteria);
                columnClauses[i] = (after, equal);
            }
        }

        BaseCriteria? seek = null;
        for (var i = count - 1; i >= 0; i--)
        {
            var (after, equal) = columnClauses[i];
            if (seek is null)
                seek = after;
            else if (after is null)
                seek = equal & seek;
            else
                seek = after | (equal & seek);
        }

        return seek ?? Criteria.False;
    }

    private sealed class FingerprintCriteriaParams : IQueryWithParams
    {
        private int nextIndex;
        public List<object?> Values { get; } = [];

        public void AddParam(string name, object? value) => Values.Add(value);

        public void SetParam(string name, object? value) => Values.Add(value);

        public Parameter AutoParam() => new(nextIndex++.IndexParam());

        public IDictionary<string, object?>? Params => null;

        public ISqlDialect Dialect => SqlSettings.DefaultDialect;
    }
}
