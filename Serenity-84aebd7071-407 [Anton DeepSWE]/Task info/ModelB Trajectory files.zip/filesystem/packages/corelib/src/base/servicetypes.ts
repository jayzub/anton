    Skip?: number;
    /** Maximum number of records to take (page size). Omit or 0 for server default. */
    Take?: number;
    /** Continuation token for server-side keyset pagination. */
    PageToken?: string;
    /** Sort expressions, e.g. `["Name ASC", "Age DESC"]`. */
    Sort?: string[];
    /** Quick-search text applied across searchable fields (or {@link ContainsField} when specified). */
    Skip?: number;
    /** Echo of `Take` from the request. */
    Take?: number;
    /** Continuation token for the next page when additional rows exist. */
    NextPageToken?: string;
}

/**
