    [JsonConverter(typeof(JsonConverters.NullAsDefaultJsonConverter))]
    public int Take { get; set; }

    /// <summary>
    /// Opaque continuation token from a previous list response. Requires Take > 0,
    /// Skip == 0, no DistinctFields, and an entity implementing IIdRow.
    /// </summary>
    public string? PageToken { get; set; }

    /// <summary>
    /// Columns to sort returned records by
    /// </summary>
