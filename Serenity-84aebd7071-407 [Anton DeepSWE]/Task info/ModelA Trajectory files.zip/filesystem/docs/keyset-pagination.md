# List continuation pagination

Synchronous and asynchronous list handlers return `NextPageToken` when a request
has `Take > 0`, `Skip == 0`, no `DistinctFields` (including an empty array), an
`IIdRow` entity, and more matching rows. Send that token as `PageToken` to fetch
the next page. Stop when `NextPageToken` is null. A missing or null `PageToken`
starts a new listing. Ordinary offset and distinct requests continue to work,
but do not return continuation tokens.

```json
{ "Take": 50, "Sort": ["Name"], "ExcludeTotalCount": true }
```

For the next page, repeat the request with `"PageToken": "<NextPageToken>"`.
Keep the sort, criteria, equality filters, quick-search text and field, and
`IncludeDeleted` unchanged. The page size and column selection may change.
Invalid, altered, or incompatible tokens produce `ValidationError` with code
`InvalidPageToken`. Tokens are opaque: clients should not parse or modify them.

Continuation ordering uses the requested sort, or the handler's native sort,
with the ID ascending as a unique tiebreaker unless already included. The initial
request retains the handler's existing ordering. Required sort and ID fields
are selected even with `KeyOnly` or column exclusions; field read permissions
are still enforced. A sort requiring an unreadable field disables continuation
on the initial request and rejects a continuation request.

Handlers fetch at most one extra row to detect another page. That probe is not
processed or returned. `Take` still reports the requested page size, `Skip`
remains zero, and `TotalCount` continues to count all matching rows rather than
only rows after the boundary. `ExcludeTotalCount` retains its existing meaning.

Tokens use authenticated encryption and preserve boundary value types and
precision. The current token key is process-scoped: application restarts
invalidate outstanding tokens, and multi-worker deployments need worker
affinity for a listing. A client receiving an invalid-token error can restart
from the first page. Continuations are not database snapshots; concurrent
changes to a row's sort values can move it across the boundary.
