    private int skip;
    private int take;
    private StringBuilder? where;

    // Keyset boundaries limit the page, not the total count. Null uses the
    // ordinary WHERE clause; an empty string explicitly means no count filter.
    internal string? WhereForCount { get; set; }
    private int intoIndex = -1;
    private List<object> into = [];
    private SqlQuery? unionQuery;
