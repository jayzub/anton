    Skip?: number;
    /** Maximum number of records to take (page size). Omit or 0 for server default. */
    Take?: number;
    /** Opaque continuation token from the previous page. Requires Take > 0, Skip == 0, and no DistinctFields. */
    PageToken?: string;
    /** Sort expressions, e.g. `["Name ASC", "Age DESC"]`. */
    Sort?: string[];
    /** Quick-search text applied across searchable fields (or {@link ContainsField} when specified). */
    Skip?: number;
    /** Echo of `Take` from the request. */
    Take?: number;
    /** Opaque continuation token, or null when no further page is available. */
    NextPageToken?: string;
}

/**
