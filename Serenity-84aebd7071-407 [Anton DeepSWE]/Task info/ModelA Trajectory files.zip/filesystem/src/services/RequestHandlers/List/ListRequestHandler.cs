        {
            Response.TotalCount = Query.ForEach(Connection, delegate ()
            {
                if (!ProcessKeysetRow())
                    return;

                var clone = ProcessEntity(Row.Clone());
                if (clone == null)
                    return;
        };

        Row = new TRow();
        InitializeKeysetPagination();

        var query = CreateQuery();
        Query = query;

        PrepareQuery(query);

        SelectKeysetFields();

        if (DistinctFields == null)
            ApplyKeyOrder(query);


        OnBeforeExecuteQuery();

        ApplyKeysetPagination();

        if (DistinctFields == null || DistinctFields.Length > 0)
        {
            ExecuteQuery();
        }

        Response.SetSkipTakeTotal(query);
        CompleteKeysetPagination();

        OnAfterExecuteQuery();

