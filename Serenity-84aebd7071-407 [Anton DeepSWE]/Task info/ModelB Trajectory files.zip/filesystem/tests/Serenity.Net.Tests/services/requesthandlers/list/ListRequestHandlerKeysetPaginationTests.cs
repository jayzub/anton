using System.Globalization;

namespace Serenity.Services;

public class ListRequestHandlerKeysetPaginationTests
{
    public enum PriorityLevel
    {
        Low = 1,
        Medium = 2,
        High = 3
    }

    public enum ShortCode : short
    {
        Alpha = 10,
        Beta = 20,
        Gamma = 30
    }

    [TableName("KeysetItems")]
    private class KeysetItemRow : Row<KeysetItemRow.RowFields>, IIdRow, INameRow, IIsActiveDeletedRow
    {
        [IdProperty, Identity]
        public int? Id { get => fields.Id[this]; set => fields.Id[this] = value; }

        [NameProperty, QuickSearch]
        public string? Name { get => fields.Name[this]; set => fields.Name[this] = value; }

        [QuickSearch]
        public string? Category { get => fields.Category[this]; set => fields.Category[this] = value; }

        public int? Score { get => fields.Score[this]; set => fields.Score[this] = value; }

        public DateTime? CreatedAt { get => fields.CreatedAt[this]; set => fields.CreatedAt[this] = value; }

        public DateTimeOffset? OccurredAt { get => fields.OccurredAt[this]; set => fields.OccurredAt[this] = value; }

        public Guid? CorrelationId { get => fields.CorrelationId[this]; set => fields.CorrelationId[this] = value; }

        public decimal? Amount { get => fields.Amount[this]; set => fields.Amount[this] = value; }

        public double? Ratio { get => fields.Ratio[this]; set => fields.Ratio[this] = value; }

        public float? Weight { get => fields.Weight[this]; set => fields.Weight[this] = value; }

        public bool? Flag { get => fields.Flag[this]; set => fields.Flag[this] = value; }

        public PriorityLevel? Priority { get => fields.Priority[this]; set => fields.Priority[this] = value; }

        public ShortCode? Code { get => (ShortCode?)fields.Code[this]; set => fields.Code[this] = (short?)value; }

        public short? IsActive { get => fields.IsActive[this]; set => fields.IsActive[this] = value; }

        Int16Field IIsActiveRow.IsActiveField => fields.IsActive;

        public class RowFields : RowFieldsBase
        {
            public Int32Field Id = null!;
            public StringField Name = null!;
            public StringField Category = null!;
            public Int32Field Score = null!;
            public DateTimeField CreatedAt = null!;
            public DateTimeOffsetField OccurredAt = null!;
            public GuidField CorrelationId = null!;
            public DecimalField Amount = null!;
            public DoubleField Ratio = null!;
            public SingleField Weight = null!;
            public BooleanField Flag = null!;
            public EnumField<PriorityLevel> Priority = null!;
            public Int16Field Code = null!;
            public Int16Field IsActive = null!;
        }
    }

    [TableName("PlainItems")]
    private class PlainIdRow : Row<PlainIdRow.RowFields>, IIdRow, INameRow
    {
        [IdProperty]
        public int? Id { get => fields.Id[this]; set => fields.Id[this] = value; }

        [NameProperty, QuickSearch]
        public string? Name { get => fields.Name[this]; set => fields.Name[this] = value; }

        public class RowFields : RowFieldsBase
        {
            public Int32Field Id = null!;
            public StringField Name = null!;
        }
    }

    [TableName("KeylessItems")]
    private class KeylessRow : Row<KeylessRow.RowFields>, INameRow
    {
        [NameProperty]
        public string? Name { get => fields.Name[this]; set => fields.Name[this] = value; }

        public class RowFields : RowFieldsBase
        {
            public StringField Name = null!;
        }
    }

    private sealed class CustomFirstPageOrderHandler(IRequestContext context) : ListRequestHandler<PlainIdRow>(context)
    {
        protected override void ApplyKeyOrder(SqlQuery query)
        {
            query.OrderBy("T0.Name", desc: true);
        }

        protected override void ApplySort(SqlQuery query)
        {
        }
    }

    private sealed class LocalizationRewriteBehavior : BaseListBehavior, IListMapFieldExpressionBehavior
    {
        public override void OnPrepareQuery(IListRequestHandler handler, SqlQuery query)
        {
            query.LeftJoin("KeysetItemsLang", new Alias("jLoc"),
                new Criteria("jLoc.ItemId = T0.Id AND jLoc.CultureId = 'tr'"));
        }

        public string? MapFieldExpression(IListRequestHandler handler, SqlQuery query, IField field)
        {
            if (field.Name == nameof(KeysetItemRow.Name))
                return "COALESCE(jLoc.Name, T0.Name)";
            return null;
        }
    }

    private sealed class ProbeInspectionBehavior : BaseListBehavior
    {
        public List<int> CountsInAfterExecute { get; } = [];
        public List<int> CountsInReturn { get; } = [];

        public override void OnAfterExecuteQuery(IListRequestHandler handler)
        {
            CountsInAfterExecute.Add(handler.Response.Entities.Count);
        }

        public override void OnReturn(IListRequestHandler handler)
        {
            CountsInReturn.Add(handler.Response.Entities.Count);
        }
    }

    private static IRequestContext CreateContext(IBehaviorProvider? behaviors = null) =>
        new NullRequestContext(behaviors).WithPermissions(_ => true);

    private static List<KeysetItemRow> CreateSeedDataset(int activeCount, int deletedCount = 1)
    {
        var list = new List<KeysetItemRow>();
        var total = activeCount + deletedCount;
        for (var i = 1; i <= total; i++)
        {
            list.Add(new KeysetItemRow
            {
                Id = i,
                Name = $"Item {i:D2}",
                Category = i % 2 == 0 ? "Even" : "Odd",
                Score = (i % 4) * 10,
                IsActive = i <= activeCount ? (short)1 : (short)-1
            });
        }
        return list;
    }

    private static MockDbConnection CreateSimulatedSqlConnection(
        ISqlDialect dialect,
        List<KeysetItemRow> rows,
        Func<KeysetItemRow, string, object?>? customExprEvaluator = null)
    {
        var nullsFirstInAsc = dialect is not (PostgresDialect or OracleDialect or FirebirdDialect);

        return new MockDbConnection { Dialect = dialect }
            .InterceptExecuteScalar(args =>
            {
                var whereSql = ExtractTopLevelClause(args.CommandText, "WHERE", ["GROUP BY", "HAVING", "ORDER BY"]);
                var count = rows.Count(r => whereSql is null || EvaluateSqlWhere(whereSql, r, args.Parameters ?? new Dictionary<string, object?>(), customExprEvaluator));
                return count;
            })
            .InterceptExecuteReader(args =>
            {
                var rawSelectSql = args.CommandText.Split(["\n---\n", ";\n"], StringSplitOptions.RemoveEmptyEntries)[0];
                var take = args.Query?.Take() ?? ParseLimitOrTop(rawSelectSql);
                var selectSql = rawSelectSql.StartsWith("SELECT * FROM (\n", StringComparison.OrdinalIgnoreCase)
                    ? rawSelectSql["SELECT * FROM (\n".Length..rawSelectSql.LastIndexOf(") WHERE x__", StringComparison.OrdinalIgnoreCase)]
                    : rawSelectSql;
                var whereSql = ExtractTopLevelClause(selectSql, "WHERE", ["GROUP BY", "HAVING", "ORDER BY", "OFFSET", "LIMIT", "FOR XML", "FOR JSON"]);
                var orderSql = ExtractTopLevelClause(selectSql, "ORDER BY", ["OFFSET", "LIMIT", "FOR XML", "FOR JSON"]);

                IEnumerable<KeysetItemRow> filtered = rows.Where(r =>
                    whereSql is null || EvaluateSqlWhere(whereSql, r, args.Parameters ?? new Dictionary<string, object?>(), customExprEvaluator));

                if (!string.IsNullOrWhiteSpace(orderSql))
                {
                    var specs = SplitTopLevelCommas(orderSql)
                        .Select(s => s.Trim())
                        .Select(s => s.EndsWith(" DESC", StringComparison.OrdinalIgnoreCase)
                            ? (Expr: s[..^5].Trim(), Desc: true)
                            : (Expr: s, Desc: false))
                        .ToArray();

                    filtered = filtered.OrderBy(r => r, Comparer<KeysetItemRow>.Create((a, b) =>
                    {
                        foreach (var (expr, desc) in specs)
                        {
                            var va = EvaluateColumnExpr(a, expr, customExprEvaluator);
                            var vb = EvaluateColumnExpr(b, expr, customExprEvaluator);
                            var cmp = CompareSqlValues(va, vb, desc, nullsFirstInAsc);
                            if (cmp != 0)
                                return cmp;
                        }
                        return 0;
                    }));
                }

                if (take > 0)
                    filtered = filtered.Take(take);

                var aliasMatches = Regex.Matches(selectSql, @"\bAS\s+(?!x__)[""\[\`]?(?<name>\w+)[""\]\`]?", RegexOptions.IgnoreCase);
                var selectedCols = aliasMatches.Select(m => m.Groups["name"].Value).ToArray();
                var anonymousItems = filtered.Select(r => (object)new
                {
                    Id = r.Id,
                    Name = customExprEvaluator != null ? customExprEvaluator(r, "COALESCE(jLoc.Name, T0.Name)") : r.Name,
                    Category = r.Category,
                    Score = r.Score,
                    CreatedAt = r.CreatedAt,
                    OccurredAt = r.OccurredAt,
                    CorrelationId = r.CorrelationId,
                    Amount = r.Amount,
                    Ratio = r.Ratio,
                    Weight = r.Weight,
                    Flag = r.Flag,
                    Priority = (int?)r.Priority,
                    Code = (short?)r.Code,
                    IsActive = r.IsActive
                }).ToArray();

                return anonymousItems.Length == 0 ? new MockDbDataReader() : new MockDbDataReader(selectedCols, anonymousItems);
            });
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task Paginates_All_Pages_Strictly_With_Probe_OverFetch_And_TotalCount(bool isAsync)
    {
        var dataset = CreateSeedDataset(activeCount: 7, deletedCount: 1);
        using var conn = CreateSimulatedSqlConnection(SqliteDialect.Instance, dataset);

        var probeInspector = new ProbeInspectionBehavior();
        var ctx = CreateContext(new MockBehaviorProvider((_, _, _) => new object[] { probeInspector }));

        var collectedIds = new List<int>();
        string? token = null;
        var pageIndex = 0;

        do
        {
            var req = new ListRequest
            {
                Take = 3,
                PageToken = token
            };

            ListResponse<KeysetItemRow> resp = isAsync
                ? await new ListRequestHandlerAsync<KeysetItemRow>(ctx).ListAsync(conn, req, TestContext.Current.CancellationToken)
                : new ListRequestHandler<KeysetItemRow>(ctx).List(conn, req);

            Assert.Equal(3, resp.Take);
            Assert.Equal(0, resp.Skip);
            Assert.Equal(7, resp.TotalCount);
            Assert.True(resp.Entities.Count <= 3);

            if (pageIndex < 2)
            {
                Assert.Equal(3, resp.Entities.Count);
                Assert.NotNull(resp.NextPageToken);
                Assert.NotEmpty(resp.NextPageToken);
                Assert.Equal(Uri.EscapeDataString(resp.NextPageToken), resp.NextPageToken);
            }
            else
            {
                Assert.Single(resp.Entities);
                Assert.Null(resp.NextPageToken);
            }

            collectedIds.AddRange(resp.Entities.Select(x => x.Id!.Value));
            token = resp.NextPageToken;
            pageIndex++;
        }
        while (token is not null);

        Assert.Equal(3, pageIndex);
        Assert.Equal([1, 2, 3, 4, 5, 6, 7], collectedIds);
        Assert.Equal([3, 3, 1], probeInspector.CountsInAfterExecute);
        Assert.Equal([3, 3, 1], probeInspector.CountsInReturn);
    }

    [Theory]
    [InlineData(0)]
    [InlineData(3)]
    public async Task Final_Page_With_Exact_Multiple_Or_Empty_Result_Returns_Null_NextPageToken(int activeCount)
    {
        var dataset = CreateSeedDataset(activeCount: activeCount, deletedCount: 1);
        using var conn = CreateSimulatedSqlConnection(SqliteDialect.Instance, dataset);

        var ctx = CreateContext();
        var syncResp = new ListRequestHandler<KeysetItemRow>(ctx).List(conn, new ListRequest { Take = 3 });
        var asyncResp = await new ListRequestHandlerAsync<KeysetItemRow>(ctx).ListAsync(
            conn, new ListRequest { Take = 3 }, TestContext.Current.CancellationToken);

        Assert.Equal(activeCount, syncResp.Entities.Count);
        Assert.Null(syncResp.NextPageToken);
        Assert.Equal(activeCount, asyncResp.Entities.Count);
        Assert.Null(asyncResp.NextPageToken);
    }

    [Fact]
    public async Task OverFetches_At_Most_Take_Plus_One_Rows_Only_When_Keyset_Is_Active()
    {
        var recordedTakes = new List<int>();
        using var conn = new MockDbConnection()
            .InterceptExecuteReader(args =>
            {
                recordedTakes.Add(args.Query.Take());
                return args.ToMockReader(
                    new { ID = 1, Name = "A" },
                    new { ID = 2, Name = "B" },
                    new { ID = 3, Name = "C" });
            });

        var ctx = CreateContext();
        var syncResp = new ListRequestHandler<IdNameRow>(ctx).List(conn, new ListRequest { Take = 2 });
        Assert.Equal(2, syncResp.Entities.Count);
        Assert.Equal([1, 2], syncResp.Entities.Select(x => x.ID!.Value));
        Assert.Equal(2, syncResp.Take);
        Assert.Equal(0, syncResp.Skip);
        Assert.NotNull(syncResp.NextPageToken);

        var asyncResp = await new ListRequestHandlerAsync<IdNameRow>(ctx).ListAsync(
            conn, new ListRequest { Take = 2, PageToken = syncResp.NextPageToken }, TestContext.Current.CancellationToken);
        Assert.Equal(2, asyncResp.Entities.Count);
        Assert.Equal(2, asyncResp.Take);
        Assert.Equal(0, asyncResp.Skip);

        var offsetResp = new ListRequestHandler<IdNameRow>(ctx).List(conn, new ListRequest { Skip = 2, Take = 2 });
        Assert.Null(offsetResp.NextPageToken);

        var keylessResp = new ListRequestHandler<KeylessRow>(ctx).List(conn, new ListRequest { Take = 2 });
        Assert.Null(keylessResp.NextPageToken);

        Assert.Equal([3, 3, 2, 2], recordedTakes);
    }

    [Theory]
    [InlineData(0, 0, false)]
    [InlineData(-5, 0, false)]
    [InlineData(5, 10, false)]
    [InlineData(5, -1, false)]
    [InlineData(5, 0, true)]
    public async Task First_Page_Failing_Preconditions_Leaves_Keyset_Inactive_And_Token_Request_Throws(
        int take, int skip, bool hasDistinct)
    {
        var dataset = CreateSeedDataset(6);
        using var conn = CreateSimulatedSqlConnection(SqliteDialect.Instance, dataset);
        var ctx = CreateContext();

        var firstReq = new ListRequest
        {
            Take = take,
            Skip = skip,
            DistinctFields = hasDistinct ? [new SortBy(nameof(KeysetItemRow.Category))] : null
        };
        var r1 = new ListRequestHandler<KeysetItemRow>(ctx).List(conn, firstReq);
        Assert.Null(r1.NextPageToken);

        var validPage1 = new ListRequestHandler<KeysetItemRow>(ctx).List(conn, new ListRequest { Take = 2 });
        Assert.NotNull(validPage1.NextPageToken);

        var badContinuation = new ListRequest
        {
            Take = take,
            Skip = skip,
            DistinctFields = hasDistinct ? [] : null,
            PageToken = validPage1.NextPageToken
        };

        Assert.Throws<ValidationError>(() => new ListRequestHandler<KeysetItemRow>(ctx).List(conn, badContinuation));
        await Assert.ThrowsAsync<ValidationError>(() =>
            new ListRequestHandlerAsync<KeysetItemRow>(ctx).ListAsync(conn, badContinuation, TestContext.Current.CancellationToken));
    }

    [Fact]
    public async Task Non_IIdRow_With_PageToken_Throws_ValidationError()
    {
        var ctx = CreateContext();
        using var conn = new MockDbConnection().InterceptExecuteReader(_ => new MockDbDataReader());

        Assert.Throws<ValidationError>(() =>
            new ListRequestHandler<KeylessRow>(ctx).List(conn, new ListRequest { Take = 5, PageToken = "abc" }));
        await Assert.ThrowsAsync<ValidationError>(() =>
            new ListRequestHandlerAsync<KeylessRow>(ctx).ListAsync(conn, new ListRequest { Take = 5, PageToken = "abc" },
                TestContext.Current.CancellationToken));
    }

    [Theory]
    [InlineData("")]
    [InlineData("   ")]
    [InlineData("not-base64!@#")]
    [InlineData("abc+def/ghi=")]
    [InlineData("e30")]
    [InlineData("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA")]
    public async Task Malformed_Tokens_Throw_ValidationError(string badToken)
    {
        var dataset = CreateSeedDataset(5);
        using var conn = CreateSimulatedSqlConnection(SqliteDialect.Instance, dataset);
        var ctx = CreateContext();

        Assert.Throws<ValidationError>(() =>
            new ListRequestHandler<KeysetItemRow>(ctx).List(conn, new ListRequest { Take = 2, PageToken = badToken }));
        await Assert.ThrowsAsync<ValidationError>(() =>
            new ListRequestHandlerAsync<KeysetItemRow>(ctx).ListAsync(conn, new ListRequest { Take = 2, PageToken = badToken },
                TestContext.Current.CancellationToken));
    }

    [Fact]
    public async Task Every_Single_Character_Corruption_Or_Truncation_Throws_ValidationError()
    {
        var dataset = CreateSeedDataset(5);
        using var conn = CreateSimulatedSqlConnection(SqliteDialect.Instance, dataset);
        var ctx = CreateContext();

        var page1 = new ListRequestHandler<KeysetItemRow>(ctx).List(conn, new ListRequest { Take = 2 });
        var validToken = page1.NextPageToken!;
        Assert.NotEmpty(validToken);

        for (var i = 0; i < validToken.Length; i++)
        {
            var chars = validToken.ToCharArray();
            chars[i] = chars[i] == 'A' ? 'B' : 'A';
            var mutated = new string(chars);

            Assert.Throws<ValidationError>(() =>
                new ListRequestHandler<KeysetItemRow>(ctx).List(conn, new ListRequest { Take = 2, PageToken = mutated }));
        }

        Assert.Throws<ValidationError>(() =>
            new ListRequestHandler<KeysetItemRow>(ctx).List(conn, new ListRequest { Take = 2, PageToken = validToken[..^1] }));
        await Assert.ThrowsAsync<ValidationError>(() =>
            new ListRequestHandlerAsync<KeysetItemRow>(ctx).ListAsync(
                conn, new ListRequest { Take = 2, PageToken = validToken + "A" }, TestContext.Current.CancellationToken));

        Assert.Throws<ValidationError>(() =>
            new ListRequestHandler<PlainIdRow>(ctx).List(conn, new ListRequest { Take = 2, PageToken = validToken }));
    }

    [Fact]
    public async Task Replay_Against_Changed_Sort_Or_Filters_Throws_ValidationError_While_Equivalent_Succeeds()
    {
        var dataset = CreateSeedDataset(6);
        using var conn = CreateSimulatedSqlConnection(SqliteDialect.Instance, dataset);
        var ctx = CreateContext();

        var page1 = new ListRequestHandler<KeysetItemRow>(ctx).List(conn, new ListRequest { Take = 2 });
        var token = page1.NextPageToken!;

        var eq1 = new ListRequestHandler<KeysetItemRow>(ctx).List(conn, new ListRequest
        {
            Take = 1,
            ExcludeTotalCount = true,
            Sort = [],
            PageToken = token
        });
        Assert.Single(eq1.Entities);
        Assert.Equal(0, eq1.TotalCount);

        var eq2 = new ListRequestHandler<KeysetItemRow>(ctx).List(conn, new ListRequest
        {
            Take = 2,
            Sort = [new SortBy("Name", false), new SortBy("Id", false)],
            PageToken = token
        });
        Assert.Equal([3, 4], eq2.Entities.Select(x => x.Id!.Value));

        ListRequest[] invalidReplays =
        [
            new() { Take = 2, PageToken = token, Sort = [new SortBy("Name", true)] },
            new() { Take = 2, PageToken = token, Sort = [new SortBy("Score", false)] },
            new() { Take = 2, PageToken = token, Sort = [new SortBy("Name", false), new SortBy("Id", true)] },
            new() { Take = 2, PageToken = token, Criteria = new Criteria("Score") > 0 },
            new() { Take = 2, PageToken = token, EqualityFilter = new Dictionary<string, object?> { ["Category"] = "Odd" } },
            new() { Take = 2, PageToken = token, ContainsText = "Item" },
            new() { Take = 2, PageToken = token, ContainsField = "Name" },
            new() { Take = 2, PageToken = token, IncludeDeleted = true }
        ];

        foreach (var badReq in invalidReplays)
        {
            Assert.Throws<ValidationError>(() => new ListRequestHandler<KeysetItemRow>(ctx).List(conn, badReq));
            await Assert.ThrowsAsync<ValidationError>(() =>
                new ListRequestHandlerAsync<KeysetItemRow>(ctx).ListAsync(conn, badReq, TestContext.Current.CancellationToken));
        }

        using var plainConn = new MockDbConnection()
            .InterceptExecuteReader(a => a.ToMockReader(new { Id = 1, Name = "A" }, new { Id = 2, Name = "B" }));
        var plainPage1 = new ListRequestHandler<PlainIdRow>(ctx).List(plainConn, new ListRequest { Take = 1 });
        Assert.Throws<ValidationError>(() => new ListRequestHandler<PlainIdRow>(ctx).List(plainConn,
            new ListRequest { Take = 1, PageToken = plainPage1.NextPageToken, IncludeDeleted = true }));
    }

    [Fact]
    public void First_Page_Without_Token_Preserves_Custom_Handler_Sort_Ordering_Verbatim()
    {
        var recordedSql = new List<string>();
        using var conn = new MockDbConnection()
            .InterceptExecuteReader(args =>
            {
                recordedSql.Add(args.CommandText);
                return args.ToMockReader(
                    new { Id = 2, Name = "B" },
                    new { Id = 1, Name = "A" },
                    new { Id = 3, Name = "C" });
            });

        var handler = new CustomFirstPageOrderHandler(CreateContext());
        var firstPage = handler.List(conn, new ListRequest { Take = 2, ExcludeTotalCount = true });
        Assert.Contains("ORDER BY T0.Name DESC", recordedSql[0]);
        Assert.DoesNotContain("T0.Id", recordedSql[0].Split("ORDER BY")[1]);

        var nextPage = handler.List(conn, new ListRequest
        {
            Take = 2,
            ExcludeTotalCount = true,
            PageToken = firstPage.NextPageToken
        });
        Assert.Contains($"ORDER BY {PlainIdRow.Fields.Name.Expression}, {PlainIdRow.Fields.Id.Expression}", recordedSql[1]);
        Assert.Equal(2, nextPage.Entities.Count);
    }

    [Fact]
    public void Preserves_Exact_Type_And_Precision_Across_All_Boundary_Types_And_Parameterizes_Values()
    {
        var exactDt = new DateTime(2025, 7, 19, 13, 45, 59, DateTimeKind.Utc).AddTicks(9876543);
        var exactDto = new DateTimeOffset(new DateTime(2025, 7, 19, 13, 45, 59).AddTicks(7654321), TimeSpan.FromHours(3.5));
        var exactGuid = Guid.Parse("f47ac10b-58cc-4372-a567-0e02b2c3d479");
        var exactDecimal = 12345678901234567890.12345600m;
        var exactDouble = Math.PI;
        var exactFloat = 1.0f / 7.0f;
        var trickyString = "O'Reilly; DROP TABLE KeysetItems; --";

        IDictionary<string, object?>? capturedParams = null;
        string? capturedSql = null;

        var callIndex = 0;
        using var conn = new MockDbConnection()
            .InterceptExecuteReader(args =>
            {
                callIndex++;
                if (callIndex == 1)
                {
                    return args.ToMockReader(
                        new
                        {
                            Id = 42,
                            Name = trickyString,
                            Category = (string?)null,
                            CreatedAt = exactDt,
                            OccurredAt = exactDto,
                            CorrelationId = exactGuid,
                            Amount = exactDecimal,
                            Ratio = exactDouble,
                            Weight = exactFloat,
                            Flag = true,
                            Priority = (int)PriorityLevel.High,
                            Code = (short)ShortCode.Beta
                        },
                        new
                        {
                            Id = 43,
                            Name = "ProbeRow",
                            Category = (string?)null,
                            CreatedAt = exactDt,
                            OccurredAt = exactDto,
                            CorrelationId = exactGuid,
                            Amount = exactDecimal,
                            Ratio = exactDouble,
                            Weight = exactFloat,
                            Flag = false,
                            Priority = (int)PriorityLevel.Low,
                            Code = (short)ShortCode.Alpha
                        });
                }

                capturedSql = args.CommandText;
                capturedParams = args.Parameters;
                return new MockDbDataReader();
            });

        var sort = new SortBy[]
        {
            new(nameof(KeysetItemRow.CreatedAt)),
            new(nameof(KeysetItemRow.OccurredAt)),
            new(nameof(KeysetItemRow.CorrelationId)),
            new(nameof(KeysetItemRow.Amount)),
            new(nameof(KeysetItemRow.Ratio)),
            new(nameof(KeysetItemRow.Weight)),
            new(nameof(KeysetItemRow.Flag)),
            new(nameof(KeysetItemRow.Priority)),
            new(nameof(KeysetItemRow.Code)),
            new(nameof(KeysetItemRow.Name)),
            new(nameof(KeysetItemRow.Category))
        };

        var handler = new ListRequestHandler<KeysetItemRow>(CreateContext());
        var page1 = handler.List(conn, new ListRequest
        {
            Take = 1,
            IncludeDeleted = true,
            ExcludeTotalCount = true,
            Sort = sort
        });
        Assert.NotNull(page1.NextPageToken);

        handler.List(conn, new ListRequest
        {
            Take = 1,
            IncludeDeleted = true,
            ExcludeTotalCount = true,
            Sort = sort,
            PageToken = page1.NextPageToken
        });

        Assert.NotNull(capturedSql);
        Assert.NotNull(capturedParams);

        Assert.DoesNotContain("O'Reilly", capturedSql);
        Assert.DoesNotContain("DROP TABLE", capturedSql);
        Assert.DoesNotContain(exactGuid.ToString(), capturedSql, StringComparison.OrdinalIgnoreCase);
        Assert.Contains(KeysetItemRow.Fields.Category.Expression + " IS NOT NULL", capturedSql);

        Assert.Equal(11, capturedParams.Count);

        var pDt = Assert.IsType<DateTime>(capturedParams["@p1"]);
        Assert.Equal(exactDt.Ticks, pDt.Ticks);
        Assert.Equal(DateTimeKind.Utc, pDt.Kind);

        var pDto = Assert.IsType<DateTimeOffset>(capturedParams["@p2"]);
        Assert.Equal(exactDto.Ticks, pDto.Ticks);
        Assert.Equal(exactDto.Offset, pDto.Offset);

        var pGuid = Assert.IsType<Guid>(capturedParams["@p3"]);
        Assert.Equal(exactGuid, pGuid);

        var pDec = Assert.IsType<decimal>(capturedParams["@p4"]);
        Assert.Equal(decimal.GetBits(exactDecimal), decimal.GetBits(pDec));

        var pDbl = Assert.IsType<double>(capturedParams["@p5"]);
        Assert.Equal(BitConverter.DoubleToInt64Bits(exactDouble), BitConverter.DoubleToInt64Bits(pDbl));

        var pFlt = Assert.IsType<float>(capturedParams["@p6"]);
        Assert.Equal(BitConverter.SingleToInt32Bits(exactFloat), BitConverter.SingleToInt32Bits(pFlt));

        var pBool = Assert.IsType<bool>(capturedParams["@p7"]);
        Assert.True(pBool);

        var pEnum1 = Assert.IsType<PriorityLevel>(capturedParams["@p8"]);
        Assert.Equal(PriorityLevel.High, pEnum1);

        var pEnum2 = Assert.IsType<ShortCode>(capturedParams["@p9"]);
        Assert.Equal(ShortCode.Beta, pEnum2);

        var pStr = Assert.IsType<string>(capturedParams["@p10"]);
        Assert.Equal(trickyString, pStr);

        var pId = Assert.IsType<int>(capturedParams["@p11"]);
        Assert.Equal(42, pId);
    }

    [Fact]
    public async Task Selects_Sort_And_Tiebreaker_Columns_Under_KeyOnly_And_ExcludeColumns()
    {
        var dataset = new List<KeysetItemRow>
        {
            new() { Id = 10, Name = "Charlie", Score = 20, IsActive = 1 },
            new() { Id = 20, Name = "Alpha",   Score = 10, IsActive = 1 },
            new() { Id = 30, Name = "Alpha",   Score = 10, IsActive = 1 },
            new() { Id = 40, Name = "Bravo",   Score = 10, IsActive = 1 },
            new() { Id = 50, Name = "Delta",   Score = 30, IsActive = 1 }
        };
        using var conn = CreateSimulatedSqlConnection(SqliteDialect.Instance, dataset);

        var ctx = CreateContext();
        var idsKeyOnly = new List<int>();
        string? tok = null;
        do
        {
            var resp = new ListRequestHandler<KeysetItemRow>(ctx).List(conn, new ListRequest
            {
                Take = 2,
                ColumnSelection = ColumnSelection.KeyOnly,
                ExcludeColumns = [nameof(KeysetItemRow.Score), nameof(KeysetItemRow.Name), nameof(KeysetItemRow.Id)],
                Sort = [new SortBy(nameof(KeysetItemRow.Score)), new SortBy(nameof(KeysetItemRow.Name))],
                PageToken = tok
            });
            idsKeyOnly.AddRange(resp.Entities.Select(x => x.Id!.Value));
            tok = resp.NextPageToken;
        }
        while (tok is not null);

        Assert.Equal([20, 30, 40, 10, 50], idsKeyOnly);

        var respAsync = await new ListRequestHandlerAsync<KeysetItemRow>(ctx).ListAsync(conn, new ListRequest
        {
            Take = 2,
            ColumnSelection = ColumnSelection.None,
            Sort = [new SortBy(nameof(KeysetItemRow.Score))]
        }, TestContext.Current.CancellationToken);
        Assert.Equal([20, 30], respAsync.Entities.Select(x => x.Id!.Value));
        Assert.NotNull(respAsync.NextPageToken);
    }

    [Fact]
    public async Task Mapped_Field_Expressions_Are_Used_Consistently_In_Select_OrderBy_And_Seek_Filter()
    {
        var dataset = new List<KeysetItemRow>
        {
            new() { Id = 1, Name = "Zebra",  IsActive = 1 },
            new() { Id = 2, Name = "Mango",  IsActive = 1 },
            new() { Id = 3, Name = "Apple",  IsActive = 1 },
            new() { Id = 4, Name = "Banana", IsActive = 1 }
        };
        var trNames = new Dictionary<int, string>
        {
            [1] = "02_ZebraTr",
            [3] = "01_Elma"
        };

        var capturedSql = new List<string>();
        using var conn = CreateSimulatedSqlConnection(
            SqliteDialect.Instance,
            dataset,
            (row, expr) => expr == "COALESCE(jLoc.Name, T0.Name)"
                ? (trNames.TryGetValue(row.Id!.Value, out var tr) ? tr : row.Name)
                : throw new NotSupportedException(expr));

        var behaviors = new MockBehaviorProvider((_, _, _) => new object[] { new LocalizationRewriteBehavior() });
        var ctx = CreateContext(behaviors);
        var handler = new ListRequestHandlerAsync<KeysetItemRow>(ctx);

        var p1 = await handler.ListAsync(conn, new ListRequest
        {
            Take = 2,
            ExcludeTotalCount = true,
            Sort = [new SortBy(nameof(KeysetItemRow.Name))]
        }, TestContext.Current.CancellationToken);

        Assert.Equal([3, 1], p1.Entities.Select(x => x.Id!.Value));
        Assert.Equal(["01_Elma", "02_ZebraTr"], p1.Entities.Select(x => x.Name));
        Assert.NotNull(p1.NextPageToken);

        var p2 = await handler.ListAsync(conn, new ListRequest
        {
            Take = 2,
            ExcludeTotalCount = true,
            Sort = [new SortBy(nameof(KeysetItemRow.Name))],
            PageToken = p1.NextPageToken
        }, TestContext.Current.CancellationToken);

        Assert.Equal([4, 2], p2.Entities.Select(x => x.Id!.Value));
        Assert.Equal(["Banana", "Mango"], p2.Entities.Select(x => x.Name));
        Assert.Null(p2.NextPageToken);

        Assert.Contains("COALESCE(jLoc.Name, T0.Name)", conn.ExecuteReaderCalls[1].CommandText);
    }

    public static IEnumerable<object[]> AllSixDialects()
    {
        yield return [SqlServer2012Dialect.Instance, true];
        yield return [MySqlDialect.Instance, true];
        yield return [SqliteDialect.Instance, true];
        yield return [PostgresDialect.Instance, false];
        yield return [OracleDialect.Instance, false];
        yield return [FirebirdDialect.Instance, false];
    }

    [Theory]
    [MemberData(nameof(AllSixDialects))]
    public void Exhaustive_MultiColumn_Null_And_Direction_Simulation_Across_All_Dialects_Parsing_Actual_Sql(
        ISqlDialect dialect, bool expectedNullsFirstInAsc)
    {
        int?[] scores = [null, -10, 10];
        string?[] names = [null, "A", "B"];
        var dataset = new List<KeysetItemRow>();
        var nextId = 1;
        foreach (var s in scores)
            foreach (var n in names)
                for (var dup = 0; dup < 2; dup++)
                    dataset.Add(new KeysetItemRow { Id = nextId++, Score = s, Name = n, IsActive = 1 });

        using var conn = CreateSimulatedSqlConnection(dialect, dataset);
        var handler = new ListRequestHandler<KeysetItemRow>(CreateContext());

        bool[][] directionCombos =
        [
            [false, false, false],
            [false, true, false],
            [true, false, false],
            [true, true, false],
            [true, false, true]
        ];

        foreach (var dirs in directionCombos)
        {
            var sort = new SortBy[]
            {
                new(nameof(KeysetItemRow.Score), dirs[0]),
                new(nameof(KeysetItemRow.Name), dirs[1]),
                new(nameof(KeysetItemRow.Id), dirs[2])
            };

            var expectedOrder = dataset
                .OrderBy(r => r, Comparer<KeysetItemRow>.Create((a, b) =>
                {
                    var c0 = CompareSqlValues(a.Score, b.Score, dirs[0], expectedNullsFirstInAsc);
                    if (c0 != 0) return c0;
                    var c1 = CompareSqlValues(a.Name, b.Name, dirs[1], expectedNullsFirstInAsc);
                    if (c1 != 0) return c1;
                    return CompareSqlValues(a.Id, b.Id, dirs[2], expectedNullsFirstInAsc);
                }))
                .Select(r => r.Id!.Value)
                .ToList();

            foreach (var take in new[] { 1, 2, 3, 5, 6, 17, 18, 25 })
            {
                var actualIds = new List<int>();
                string? token = null;
                var guard = 0;

                do
                {
                    var resp = handler.List(conn, new ListRequest
                    {
                        Take = take,
                        IncludeDeleted = true,
                        ExcludeTotalCount = true,
                        Sort = sort,
                        PageToken = token
                    });
                    actualIds.AddRange(resp.Entities.Select(x => x.Id!.Value));
                    token = resp.NextPageToken;
                    Assert.True(++guard <= dataset.Count + 2, "Pagination did not terminate!");
                }
                while (token is not null);

                Assert.Equal(expectedOrder, actualIds);
            }
        }
    }

    // Minimal recursive-descent evaluator over the actual emitted SQL WHERE & ORDER BY clauses
    private static List<string> SplitTopLevelCommas(string input)
    {
        var list = new List<string>();
        var depth = 0;
        var start = 0;
        for (var i = 0; i < input.Length; i++)
        {
            if (input[i] == '(') depth++;
            else if (input[i] == ')') depth--;
            else if (input[i] == ',' && depth == 0)
            {
                list.Add(input[start..i]);
                start = i + 1;
            }
        }
        list.Add(input[start..]);
        return list;
    }

    private static string? ExtractTopLevelClause(string sql, string clauseKeyword, string[] terminators)
    {
        var startIdx = FindTopLevelKeyword(sql, clauseKeyword, 0);
        if (startIdx < 0)
            return null;

        var contentStart = startIdx + clauseKeyword.Length;
        var endIdx = sql.Length;
        foreach (var term in terminators)
        {
            var idx = FindTopLevelKeyword(sql, term, contentStart);
            if (idx >= 0 && idx < endIdx)
                endIdx = idx;
        }
        return sql[contentStart..endIdx].Trim();
    }

    private static int FindTopLevelKeyword(string sql, string keyword, int fromIndex)
    {
        var depth = 0;
        var inSingleQuote = false;
        for (var i = fromIndex; i <= sql.Length - keyword.Length; i++)
        {
            var c = sql[i];
            if (c == '\'')
                inSingleQuote = !inSingleQuote;
            else if (!inSingleQuote)
            {
                if (c == '(') depth++;
                else if (c == ')') depth = Math.Max(0, depth - 1);
                else if (depth == 0 &&
                         (i == 0 || !char.IsLetterOrDigit(sql[i - 1])) &&
                         string.Compare(sql, i, keyword, 0, keyword.Length, StringComparison.OrdinalIgnoreCase) == 0 &&
                         (i + keyword.Length == sql.Length || !char.IsLetterOrDigit(sql[i + keyword.Length])))
                {
                    return i;
                }
            }
        }
        return -1;
    }

    private static int ParseLimitOrTop(string sql)
    {
        var m = Regex.Match(sql, @"\b(?:LIMIT|FIRST|FETCH\s+NEXT|TOP)\s+(\d+)\b", RegexOptions.IgnoreCase);
        if (m.Success)
            return int.Parse(m.Groups[1].Value, CultureInfo.InvariantCulture);
        m = Regex.Match(sql, @"\bROWNUM\s*<=\s*(\d+)\b", RegexOptions.IgnoreCase);
        return m.Success ? int.Parse(m.Groups[1].Value, CultureInfo.InvariantCulture) : 0;
    }

    private static object? EvaluateColumnExpr(
        KeysetItemRow row,
        string expr,
        Func<KeysetItemRow, string, object?>? customExprEvaluator)
    {
        expr = expr.Trim();
        if (customExprEvaluator != null && expr == "COALESCE(jLoc.Name, T0.Name)")
            return customExprEvaluator(row, expr);

        var colName = expr.StartsWith("T0.", StringComparison.OrdinalIgnoreCase) ? expr[3..] : expr;
        colName = SqlSyntax.Unquote(colName);
        var field = KeysetItemRow.Fields.FindField(colName)!;
        return field.AsObject(row);
    }

    private static int CompareSqlValues(object? a, object? b, bool desc, bool nullsFirstInAsc)
    {
        var nullsFirst = nullsFirstInAsc != desc;
        if (a is null && b is null) return 0;
        if (a is null) return nullsFirst ? -1 : 1;
        if (b is null) return nullsFirst ? 1 : -1;
        int cmp;
        if (a is string sa && b is string sb)
            cmp = string.CompareOrdinal(sa, sb);
        else
            cmp = Comparer<object>.Default.Compare(
                Convert.ChangeType(a, b.GetType(), CultureInfo.InvariantCulture), b);
        return desc ? -cmp : cmp;
    }

    private static bool EvaluateSqlWhere(
        string expr,
        KeysetItemRow row,
        IDictionary<string, object?> parameters,
        Func<KeysetItemRow, string, object?>? customExprEvaluator)
    {
        return EvalSql3VL(expr, row, parameters, customExprEvaluator) == true;
    }

    private static bool? EvalSql3VL(
        string expr,
        KeysetItemRow row,
        IDictionary<string, object?> parameters,
        Func<KeysetItemRow, string, object?>? customExprEvaluator)
    {
        expr = StripOuterParens(expr.Trim());

        var orPos = SplitTopLevelBinaryLogical(expr, "OR");
        if (orPos >= 0)
        {
            var l = EvalSql3VL(expr[..orPos], row, parameters, customExprEvaluator);
            var r = EvalSql3VL(expr[(orPos + 2)..], row, parameters, customExprEvaluator);
            if (l == true || r == true) return true;
            if (l == false && r == false) return false;
            return null;
        }

        var andPos = SplitTopLevelBinaryLogical(expr, "AND");
        if (andPos >= 0)
        {
            var l = EvalSql3VL(expr[..andPos], row, parameters, customExprEvaluator);
            var r = EvalSql3VL(expr[(andPos + 3)..], row, parameters, customExprEvaluator);
            if (l == false || r == false) return false;
            if (l == true && r == true) return true;
            return null;
        }

        if (expr.EndsWith(" IS NOT NULL", StringComparison.OrdinalIgnoreCase))
            return ResolveAtom(expr[..^12].Trim(), row, parameters, customExprEvaluator) is not null;

        if (expr.EndsWith(" IS NULL", StringComparison.OrdinalIgnoreCase))
            return ResolveAtom(expr[..^8].Trim(), row, parameters, customExprEvaluator) is null;

        foreach (var op in new[] { ">=", "<=", "!=", "<>", "=", ">", "<" })
        {
            var idx = FindTopLevelOperator(expr, op);
            if (idx > 0)
            {
                var lv = ResolveAtom(expr[..idx].Trim(), row, parameters, customExprEvaluator);
                var rv = ResolveAtom(expr[(idx + op.Length)..].Trim(), row, parameters, customExprEvaluator);
                if (lv is null || rv is null)
                    return null;

                var cmp = lv is string ls && rv is string rs
                    ? string.CompareOrdinal(ls, rs)
                    : Convert.ToDecimal(lv, CultureInfo.InvariantCulture)
                        .CompareTo(Convert.ToDecimal(rv, CultureInfo.InvariantCulture));

                return op switch
                {
                    "=" => cmp == 0,
                    "!=" or "<>" => cmp != 0,
                    ">" => cmp > 0,
                    ">=" => cmp >= 0,
                    "<" => cmp < 0,
                    "<=" => cmp <= 0,
                    _ => throw new NotSupportedException(op)
                };
            }
        }

        throw new NotSupportedException("Unsupported SQL predicate: " + expr);
    }

    private static string StripOuterParens(string s)
    {
        while (s.Length >= 2 && s[0] == '(' && s[^1] == ')')
        {
            var depth = 0;
            var wrapsAll = true;
            for (var i = 0; i < s.Length; i++)
            {
                if (s[i] == '(') depth++;
                else if (s[i] == ')') depth--;
                if (depth == 0 && i < s.Length - 1)
                {
                    wrapsAll = false;
                    break;
                }
            }
            if (!wrapsAll)
                break;
            s = s[1..^1].Trim();
        }
        return s;
    }

    private static int SplitTopLevelBinaryLogical(string expr, string opKeyword)
    {
        var depth = 0;
        for (var i = 0; i <= expr.Length - opKeyword.Length; i++)
        {
            if (expr[i] == '(') depth++;
            else if (expr[i] == ')') depth--;
            else if (depth == 0 &&
                     i > 0 && char.IsWhiteSpace(expr[i - 1]) &&
                     string.Compare(expr, i, opKeyword, 0, opKeyword.Length, StringComparison.OrdinalIgnoreCase) == 0 &&
                     i + opKeyword.Length < expr.Length && char.IsWhiteSpace(expr[i + opKeyword.Length]))
            {
                return i;
            }
        }
        return -1;
    }

    private static int FindTopLevelOperator(string expr, string op)
    {
        var depth = 0;
        for (var i = 0; i <= expr.Length - op.Length; i++)
        {
            if (expr[i] == '(') depth++;
            else if (expr[i] == ')') depth--;
            else if (depth == 0 && string.CompareOrdinal(expr, i, op, 0, op.Length) == 0)
                return i;
        }
        return -1;
    }

    private static object? ResolveAtom(
        string token,
        KeysetItemRow row,
        IDictionary<string, object?> parameters,
        Func<KeysetItemRow, string, object?>? customExprEvaluator)
    {
        token = StripOuterParens(token);
        if (token.StartsWith('@'))
            return parameters[token];
        if (int.TryParse(token, NumberStyles.Integer, CultureInfo.InvariantCulture, out var literalInt))
            return literalInt;
        return EvaluateColumnExpr(row, token, customExprEvaluator);
    }
}
